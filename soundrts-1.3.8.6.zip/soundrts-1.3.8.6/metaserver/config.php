<?php

// fill in the following information

// hostname (or hostname:port) of the MySQL server
$dbhost = '';

// name of the database
$dbname = '';

// username
$dbuser = '';

// password
$dbpasswd = '';

?>
