import math
import random
import time

import pygame
from .definitions import rules  # 添加这行导入语句
from . import config, parameters
from . import msgparts as mp
from .animation import noise
from .clientgamenews import must_be_said
from .clientgameorder import get_orders_list, substitute_args
from .clientmedia import sounds, voice
from .definitions import style
from .lib.log import exception, warning
from .lib.msgs import nb2msg
from .lib.nofloat import PRECISION
from .lib.sound import distance, psounds, angle
from .worldunit import BuildingSite

# minimal interval (in seconds) between 2 sounds
FOOTSTEP_LIMIT = 0.1


def direction_to_msgpart(o):
    o = round(o / 45) * 45
    while o >= 360:
        o -= 360
    while o < 0:
        o += 360
    if o == 0:
        return mp.EAST
    elif o == 45:
        return mp.NORTHEAST
    elif o == 90:
        return mp.NORTH
    elif o == 135:
        return mp.NORTHWEST
    elif o == 180:
        return mp.WEST
    elif o == 225:
        return mp.SOUTHWEST
    elif o == 270:
        return mp.SOUTH
    elif o == 315:
        return mp.SOUTHEAST


def compute_title(type_name):
    t = style.get(type_name, "title")
    if t is None:
        return []
    else:
        return [int(x) for x in t]


def _order_title_msg(order, interface, nb=1):
    if order.is_deferred:
        result = style.get("messages", "production_deferred")
    else:
        result = []
    result += style.get(order.keyword, "title")
    if order.type is not None:
        t = style.get(order.type.type_name, "title")
        if nb != 1:
            t = nb2msg(nb) + t
        result = substitute_args(result, [t])
    if hasattr(order, "targets"):  # patrol
        for t in getattr(order, "targets"):
            result += EntityView(interface, t).title + mp.COMMA
    elif order.target is not None:
        if order.keyword == "build_phase_two":
            result += style.get(order.target.type.type_name, "title")
        else:
            result += EntityView(interface, order.target).title
    return mp.COMMA + result


class SquareView:
    def __init__(self, interface, model):
        self.interface = interface
        self.model = model

    def __getattr__(self, name):
        v = getattr(self.model, name)
        if name in ["x", "y"]:
            v /= 1000.0
        return v

    @property
    def fow(self):
        return self.model not in self.interface.scouted_squares


class EntityView:

    next_step = None
#添加类变量用来处理喊杀声的音效与冷却
    _last_shout_time = 0  # 上次喊杀时间
    _shout_cooldown = 10000  # 喊杀冷却时间(10秒)
    _min_units_for_shout = 5  # 触发喊杀的最小单位数
    _units_per_volume = 5  # 每5个单位增加1音量
    _base_volume = 1  # 基础音量
    _max_volume_increase = 5  # 最大音量增加值
    # 添加类变量用于攻击音效冷却
    _last_attack_sound_time = 0  # 上次攻击音效时间
    _attack_sound_cooldown = 8000  # 攻击音效冷却时间(1秒)

    def __init__(self, interface, model):
        self.interface = interface
        self.model = model
        self.footstep_random = (
            random.random() * 0.2
        )  # to avoid strange synchronicity of footsteps when several units are walking

    def _get_battle_shout_volume(self, defender_units, attacker_units):
        """计算喊杀声的音量"""
        total_units = max(defender_units, attacker_units)
        volume_increase = min((total_units - self._min_units_for_shout) // self._units_per_volume, 
                            self._max_volume_increase)
        return self._base_volume + (volume_increase * 1)  # 每次增加1音量

    def _should_play_battle_shout(self, attacker_id, current_time):
        """判断是否应该播放喊杀音效,返回音量"""
        # 检查冷却时间
        if current_time - EntityView._last_shout_time < EntityView._shout_cooldown:
            return 0
            
        # 获取攻击者
        attacker = self.interface.dobjets.get(attacker_id)
        if not attacker:
            return 0
            
        # 计算双方参战单位数量
        defender_units = sum(1 for u in self.player.units 
                           if u.place is self.place and u.menace)
        attacker_units = sum(1 for u in attacker.player.units 
                           if u.place is self.place and u.menace)
                            
        # 当任意一方单位数量达到要求时触发
        if (defender_units >= EntityView._min_units_for_shout or 
            attacker_units >= EntityView._min_units_for_shout):
            return self._get_battle_shout_volume(defender_units, attacker_units)
        return 0

    @property
    def fow(self):
        return self.is_memory

    @property
    def footstep_interval(self):
        try:
            s = self.model.actual_speed
        except:
            s = self.model.speed
        try:
            return 1000.0 / s / 2 + self.footstep_random
        except ZeroDivisionError:
            return 1000.0 * 999

    @property
    def when_moving_through(self):
        return style.get(self.model.type_name, "when_moving_through")

    @property
    def is_an_exit(self):
        return style.has(self.model.type_name, "when_moving_through")

    def is_in(self, place):
        # a unit inside a transporter is also inside the place of the transporter
        if getattr(self, "is_inside", False):
            return self.place.outside is place
        # For the interface, a blocker is also on the other side of the exit.
        return (
            self.place is place
            or getattr(self, "blocked_exit", None)
            and self.blocked_exit.other_side.place is place
        )

    def on_disappear(self):
        """处理单位消失的音效"""
        self.launch_event_style("disappear")

    def on_death(self):
        """处理单位死亡的音效"""
        self.launch_event_style("death")

    def __getattr__(self, name):
        if name == "model":
            return
        v = getattr(self.model, name)
        if name in ["x", "y"]:
            v /= 1000.0
        elif name in ("qty", "hp", "hp_max", "mana", "mana_max"):
            v = int(v / PRECISION)
        return v

    def __getstate__(self):
        if "_noise" in self.__dict__:
            state = self.__dict__.copy()
            del state["_noise"]
            return state
        return self.__dict__

    @property
    def ext_title(self):
        try:
            return self.title + mp.AT + self.place.title
        except:
            exception("problem with %s.ext_title", self.type_name)

    def _menu(self, strict=False):
        menu = []
        try:  # TODO: remove this "try... except" when rules.txt checking is implemented
            for order_class in get_orders_list():
                menu.extend(order_class.menu(self, strict=strict))
        except:
            exception("problem with %s.menu() of %s", order_class, self.type_name)
        return menu

    @property
    def menu(self):
        return self._menu()

    @property
    def strict_menu(self):
        return self._menu(strict=True)

    @property
    def orders_txt(self):
        t = []
        prev = None
        nb = 0
        for o in self.orders:
            if prev:
                if o.keyword == "train" and prev.type == o.type:
                    nb += 1
                else:
                    t += _order_title_msg(prev, self.interface, nb)
                    if o.keyword == "train":
                        prev = o
                        nb = 1
                    else:
                        t += _order_title_msg(o, self.interface)
                        prev = None
            elif o.keyword == "train":
                prev = o
                nb = 1
            else:
                t += _order_title_msg(o, self.interface)
            if o.keyword == "patrol":
                break
        if prev:
            t += _order_title_msg(prev, self.interface, nb)
        return t + mp.COMMA

    @property
    def title(self):
        if isinstance(self.model, BuildingSite):
            title = compute_title(self.type.type_name) + compute_title(
                BuildingSite.type_name
            )
        else:
            title = self.short_title[:]
        if self.player:
            if self.player == self.interface.player:
                title += nb2msg(self.number)
            else:
                if self.player in self.interface.player.allied:
                    title += mp.ALLY
                else:
                    title += mp.ENEMY
                title += mp.COMMA + self.player.name + mp.COMMA
        if self.is_memory:
            title += mp.IN_THE_FOG + mp.COMMA
            if self.speed:
                s = (self.world.time - self.time_stamp) // 1000
                m = s // 60
                if m:
                    title += nb2msg(m) + mp.MINUTES
                elif s:
                    title += nb2msg(s) + mp.SECONDS
                title += mp.COMMA
        return title

    @property
    def short_title(self):
        if self.type_name == "buildingsite":
            return compute_title(self.type.type_name) + compute_title(self.type_name)
        else:
            return compute_title(self.type_name)

    @property
    def hp_status(self):
        return nb2msg(self.hp) + mp.HITPOINTS_ON + nb2msg(self.hp_max)

    @property
    def mana_status(self):
        if self.mana_max > 0:
            return nb2msg(self.mana) + mp.MANA_POINTS_ON + nb2msg(self.mana_max)
        else:
            return []

    @property
    def upgrades_status(self):
        result = []
        for u in self.upgrades:
            result += style.get(u, "title")
        return result

    @property
    def description(self):
        d = []
        try:
            if hasattr(self, "qty") and self.qty:
                d += (
                    mp.COMMA
                    + mp.CONTAINS
                    + nb2msg(self.qty)
                    + style.get("parameters", f"{self.resource_type}_title")  # 移除了 resource_ 前缀
                )
            if hasattr(self, "hp"):
                d += mp.COMMA + self.hp_status
            if hasattr(self, "mana"):
                d += mp.COMMA + self.mana_status
            if hasattr(self, "upgrades"):
                d += mp.COMMA + self.upgrades_status
            if getattr(self, "is_invisible", 0) or getattr(self, "is_cloaked", 0):
                d += mp.COMMA + mp.INVISIBLE
            if getattr(self, "is_a_detector", 0):
                d += mp.COMMA + mp.DETECTOR
            if getattr(self, "is_a_cloaker", 0):
                d += mp.COMMA + mp.CLOAKER
        except:
            pass  # a warning is given by style.get()
        return d

    def _direction_msg(self):
        x, y = self.interface.place_xy
        d = distance(x, y, self.x, self.y)
        if d < self.interface.square_width / 3 / 2:
            return mp.AT_THE_CENTER
        direction = math.degrees(angle(x, y, self.x, self.y, 0))
        mp_direction = direction_to_msgpart(direction)
        if mp_direction == mp.EAST:
            return mp.TO_THE_EAST  # special case in French
        if mp_direction == mp.WEST:
            return mp.TO_THE_WEST  # special case in French
        return mp.TO_THE + mp_direction

    @property
    def positional_description(self):
        d = self.title
        if self.interface.immersion:
            d += mp.AT2 + nb2msg(self.interface.distance(self)) + mp.METERS
        return d + self._direction_msg() + self.description

    def is_a_useful_target(self):
        # (useful for a worker)
        # resource deposits, building lands, damaged repairable units or buildings, blockable exits
        return (
            self.qty > 0
            or self.is_a_building_land
            or self.is_repairable
            and self.hp < self.hp_max
            or self.is_an_exit
        )

    def shape(self):
        shape = style.get(self.type_name, "shape", warn_if_not_found=False)
        if shape:
            return shape[0]

    def color(self):
        color = style.get(self.type_name, "color", warn_if_not_found=False)
        try:
            return pygame.Color(color[0])
        except:
            try:
                return (
                    255,
                    (int(self.short_title[0]) * int(self.short_title[0])) % 256,
                    int(self.short_title[0]) % 256,
                )
            except:
                return (255, 255, 255)

    def corrected_color(self):
        if self.model in self.interface.memory:
            return tuple([x // 2 for x in self.color()])
        else:
            return self.color()

    def _terrain_footstep(self):
        t = self.place.type_name
        if t:
            g = style.get(t, "ground")
            if g and style.has(self.type_name, "move_on_%s" % g[0]):
                return style.get(self.type_name, "move_on_%s" % g[0])

    def footstepnoise(self):
        # assert: "only immobile objects must be taken into account"
        result = style.get(self.type_name, "move")
        if self.airground_type == "ground" and self._terrain_footstep():
            return self._terrain_footstep()
        elif (
            self.airground_type == "ground" and len(self.place.objects) < 30
        ):  # save CPU
            d_min = 9999999
            for m in self.place.objects:
                if getattr(m, "speed", 0):
                    continue
                g = style.get(m.type_name, "ground")
                if g and style.has(self.type_name, "move_on_%s" % g[0]):
                    try:
                        k = float(g[1])
                    except IndexError:
                        k = 1.0
                    try:
                        o = self.interface.dobjets[m.id]
                    except KeyError:  # probably caused by the world client updates
                        continue
                    try:
                        d = distance(o.x, o.y, self.x, self.y) / k
                    except ZeroDivisionError:
                        continue
                    if d < d_min:
                        result = style.get(self.type_name, "move_on_%s" % g[0])
                        d_min = d
        return result

    def footstep(self):
        if self.is_moving and not self.is_memory:
            if self.next_step is None:
                self.step_side = 1
                self.next_step = (
                    time.time()
                    + random.random()
                    * self.footstep_interval
                    / self.interface.real_speed
                )  # start at different moments
            elif time.time() > self.next_step:
                if self.interface.immersion and (self.x, self.y) == (
                    self.interface.x,
                    self.interface.y,
                ):
                    v = 1 / 2.0
                else:
                    v = 1
                try:
                    self.launch_event(
                        self.footstepnoise()[self.step_side],
                        v,
                        priority=-10,
                        limit=FOOTSTEP_LIMIT,
                    )
                except IndexError:
                    pass
                self.next_step = (
                    time.time() + self.footstep_interval / self.interface.real_speed
                )
                self.step_side = 1 - self.step_side
        else:
            self.next_step = None

    def get_style(self, attr):
        st = style.get(self.type_name, attr)
        if st and st[0] == "if_me":
            if self.player in self.interface.player.allied:
                return st[1]
            else:
                return st[2]
        return st

    def _get_noise_style(self):
        if self.activity:
            st = self.get_style("noise_when_%s" % self.activity)
            if st:
                return st
        if hasattr(self, "hp"):
            if self.hp < self.hp_max / 3:
                st = self.get_style("noise_if_very_damaged")
                if st:
                    return st
            if self.hp < self.hp_max * 2 / 3:
                st = self.get_style("noise_if_damaged")
                if st:
                    return st
        return self.get_style("noise")

    _noise = None

    def _set_noise(self, st):
        if self._noise:
            if st is self._noise.style:
                self._noise.update()
            else:
                self._noise.stop()
                self._noise = noise(self, st)
        else:
            self._noise = noise(self, st)

    def update_noise(self):
        st = self._get_noise_style()
        self._set_noise(st)

    @property
    def is_local(self):
        return self.place is self.interface.place or parameters.d.get("render_nearby_objects", False) and self.interface.place and self.place in self.interface.place.neighbors

    def launch_event_style(self, attr, alert=False, priority=0):
        st = self.get_style(attr)
        if not st:
            return
        s = random.choice(st)
        if alert and not self.is_local:
            self.launch_alert(s)
        else:
            self.launch_event(s, priority=priority)

    def on_use_complete(self, skill):
        st = style.get(skill, "alert")
        if not st:
            return
        s = random.choice(st)
        self.launch_alert(s)

    def animate(self):
        if self.is_local:
            self.footstep()
            self.update_noise()
            self.render_hp()

    def stop(self):
        if self._noise:
            self._noise.stop()

    previous_hp = None

    def _hp_noise(self, hp):
        return int(hp * 10 / self.hp_max)

    def render_hp_evolution(self):
        if self.previous_hp is not None:
            if self.hp < self.previous_hp or self._hp_noise(  # always noise if less HP
                self.hp
            ) != self._hp_noise(self.previous_hp):
                self.launch_event_style("proportion_%s" % self._hp_noise(self.hp))
            if self.hp > self.previous_hp and self.is_healable:
                self.launch_event_style("healed")

    def render_hp(self):
        if hasattr(self, "hp"):
            if self.hp < 0:
                return  # TODO: remove this line (isolate the UI or use a deep copy of perception)
            if self.hp != self.previous_hp:
                self.render_hp_evolution()
                self.previous_hp = self.hp

    def notify(self, event_and_args):
        """处理实体事件通知"""
        e_a = event_and_args.split(",")
        event = e_a[0]
        args = e_a[1:]
        
    # 特殊处理攻击音效
        if event in ["launch_matk", "launch_ratk"]:
        # 如果有额外参数（单位类型和ID），使用这些参数
            if len(args) >= 2:
                unit_type = args[0]
                unit_id = args[1]
            # 使用指定单位类型的音效
                self.launch_event_style(event)
            else:
            # 使用自己的音效
                self.launch_event_style(event)
        # 处理资源生产完成通知
        elif event.startswith("produced_"):
            # 例如: produced_1,50 (生产了50个金子)
            resource_type = "resource" + event.split("_")[1]
            qty = int(args[0]) if args and args[0].isdigit() else 0
            self.on_produced(resource_type, qty)
        # 处理资源生产完成事件（只播放声音，不显示提示）
        elif event == "resource_complete":
            self.on_resource_complete()
        elif hasattr(self, "on_" + event):
            getattr(self, "on_" + event)(*args)
        else:
            self.launch_event_style(event)

    def on_collision(self):
        self.launch_event_style("blocked")  # "blocked" is more precise than "collision"

    def on_attack(self):
        # 获取当前时间
        current_time = int(time.time() * 1000)
        
        # 检查是否在冷却中
        if current_time - EntityView._last_attack_sound_time >= EntityView._attack_sound_cooldown:
            self.launch_event_style("attack", alert=True)
            EntityView._last_attack_sound_time = current_time

    def on_flee(self):
        self.launch_event_style("flee", alert=True)

    def on_store(self, resource_type):
        self.launch_event_style(f"store_{resource_type}")

    def on_order_ok(self):
        if self.player is not self.interface.player:
            return
        self.launch_event_style("order_ok", alert=True)

    def on_order_impossible(self, reason=None):
        if self.player is not self.interface.player:
            return
        self.launch_event_style("order_impossible", alert=True)
        if reason is not None:
            voice.info(style.get("messages", reason))

    def on_production_deferred(self):
        voice.info(style.get("messages", "production_deferred"))

    def on_win_fight(self):
        self.launch_event_style("win_fight", alert=True)
        self.interface.units_alert_if_needed()

    def on_lose_fight(self):
        self.launch_event_style("lose_fight", alert=True)
        self.interface.units_alert_if_needed(place=self.place)

    def launch_event(self, sound, volume=1, priority=0, limit=0, ambient=False):
        if self.place is self.interface.place:
            pass
        elif self.place in getattr(self.interface.place, "neighbors", []):
            priority -= 1
        else:
            return
        if self.is_memory:
            volume *= parameters.d.get("fog_of_war_factor", 0.5)
        return psounds.play(
            sounds.get_sound(sound), volume, self.x, self.y, priority, limit, ambient
        )

    def launch_alert(self, sound):
        if self.is_inside:
            place = self.place.container.place
        else:
            place = self.place
        self.interface.launch_alert(place, sound)

    def on_death_by(self, attacker_id):
        attacker = self.interface.dobjets.get(attacker_id)
        if self.player is self.interface.player:
            self.interface.lost_units.append([self.short_title, self.place])
        if getattr(attacker, "player", None) is self.interface.player:
            self.interface.neutralized_units.append(
                [self.short_title, self.place]
            )  # TODO: "de " self.player.name
        friends = [
            u for u in self.player.units if u.place is self.place and u.id != self.id
        ]
        friend_soldiers = [u for u in friends if u.menace]
        # two cases requires an alert:
        # - the last soldier died (no more protection)
        # - the last "non soldier" unit died (no more unit at all)
        if not friend_soldiers and self.menace or not friends:
            if self.player == self.interface.player:
                self.on_lose_fight()
            if getattr(attacker, "player", None) == self.interface.player:
                attacker.on_win_fight()

    def unit_attacked_alert(self):
        self.interface.alert_squares[self.place] = time.time()
        self.interface.squares_alert_if_needed()
        if (
            self.interface.previous_unit_attacked_alert is None
            or time.time() > self.interface.previous_unit_attacked_alert + 10
        ):
            self.launch_event_style("alert", alert=True)
            self.interface.previous_unit_attacked_alert = time.time()

    def on_wounded(self, attacker_type, attacker_id, level):
        print(f"DEBUG: Received wound notification - attacker: {attacker_type}, level: {level}")
        
        # 检查喊杀条件
        current_time = int(time.time() * 1000)
        volume = self._should_play_battle_shout(attacker_id, current_time)
        if volume > 0:
            print(f"DEBUG: Battle shout conditions met - playing shout sound")
            self.launch_event_style("shouts")  # 改回原来的方法
            EntityView._last_shout_time = current_time
        
        if self.player == self.interface.player:
            self.unit_attacked_alert()
            
        # 1. 确定是近战还是远程攻击
        is_melee = self._is_melee_attack(attacker_type)

        # 2. 获取攻击等级
        try:
            level = int(level)
            print(f"DEBUG: Converted level to int: {level}")
        except (ValueError, TypeError):
            level = 0
        
        # 3. 根据等级决定播放哪个音效
        if level > 0:
            # 播放等级音效
            level_sound = self._get_level_hit_sound(attacker_type, level, is_melee)
            if level_sound:
                self.launch_event(level_sound)
        else:
            # 播放基础音效
            if is_melee:
                hit_sound = self._get_melee_hit_sound(attacker_type)
            else:
                hit_sound = self._get_ranged_hit_sound(attacker_type)
            
            if hit_sound:
                self.launch_event(hit_sound)

        # 4. 显示攻击效果
        if self.interface.display_is_active and attacker_id in self.interface.dobjets:
            self.interface.grid_view.display_attack(attacker_id, self)

    def _is_melee_attack(self, attacker_type):
        """判断是否为近战攻击"""
        unit = rules.unit_class(attacker_type)
        # 如果单位有远程攻击范围，则认为是远程单位
        if hasattr(unit, 'rdg_range') and unit.rdg_range > 0:
            return False
        return True  # 默认为近战

    def _get_melee_hit_sound(self, attacker_type):
        """获取近战命中音效"""
        # 1. 先查找针对特定单位类型的音效
        try:
            vs_sounds = style.get(attacker_type, "matk_hit_vs")
            if vs_sounds and len(vs_sounds) >= 2:
                target_type = vs_sounds[0]
                sound_id = vs_sounds[1]
                # 检查目标类型及其继承链
                if self.type_name == target_type or target_type in getattr(self, 'expanded_is_a', []):
                    return sound_id
        except:
            pass
            
        # 2. 再查找通用近战命中音效
        try:
            s = style.get(attacker_type, "matk_hit")
            if s:
                return random.choice(s)
        except:
            pass
        
        return None

    def _get_ranged_hit_sound(self, attacker_type):
        """获取远程命中音效"""
        # 1. 先查找针对特定单位类型的音效
        try:
            vs_sounds = style.get(attacker_type, "ratk_hit_vs")
            if vs_sounds and len(vs_sounds) >= 2:
                target_type = vs_sounds[0]
                sound_id = vs_sounds[1]
                # 检查目标类型及其继承链
                if self.type_name == target_type or target_type in getattr(self, 'expanded_is_a', []):
                    return sound_id
        except:
            pass
            
        # 2. 再查找通用远程命中音效
        try:
            s = style.get(attacker_type, "ratk_hit")
            if s:
                return random.choice(s)
        except:
            pass
        
        return None

    def _get_level_hit_sound(self, attacker_type, level, is_melee):
        """获取等级相关命中音效"""
        prefix = "matk" if is_melee else "ratk"
        
        # 1. 先获取普通等级音效和普通命中音效作为基础
        base_level_sound = None
        base_hit_sound = None
        
        try:
            s = style.get(attacker_type, f"{prefix}_hit_lv_{level}")
            if s:
                base_level_sound = random.choice(s)
        except:
            pass
            
        try:
            s = style.get(attacker_type, f"{prefix}_hit")
            if s:
                base_hit_sound = random.choice(s)
        except:
            pass
            
        # 2. 检查特殊等级音效
        try:
            vs_sounds = style.get(attacker_type, f"{prefix}_hit_lv_{level}_vs")
            if vs_sounds and len(vs_sounds) >= 2:
                target_type = vs_sounds[0]
                sound_id = vs_sounds[1]
                # 检查目标类型及其继承链
                if (self.type_name == target_type or 
                    target_type in getattr(self, 'expanded_is_a', [])):
                    return sound_id
        except:
            pass
            
        # 3. 如果没有特殊等级音效，检查普通特定音效
        try:
            vs_sounds = style.get(attacker_type, f"{prefix}_hit_vs")
            if vs_sounds and len(vs_sounds) >= 2:
                target_type = vs_sounds[0]
                sound_id = vs_sounds[1]
                # 检查目标类型及其继承链
                if (self.type_name == target_type or 
                    target_type in getattr(self, 'expanded_is_a', [])):
                    return sound_id
        except:
            pass
            
        # 4. 如果没有任何特定音效，优先使用普通等级音效，其次是普通命中音效
        return base_level_sound or base_hit_sound

    def on_dodge(self, attacker_type, is_melee):
        """处理闪避事件"""
        # 将字符串转换为布尔值 - 更宽松的判断
        is_melee = str(is_melee).lower() in ('true', '1', 'yes')
        
        # 获取闪避音效
        dodge_sound = self._get_dodge_sound(attacker_type, is_melee)
        if dodge_sound:
            self.launch_event(dodge_sound)

    def _get_dodge_sound(self, attacker_type, is_melee):
        """获取闪避音效"""
        prefix = "matk" if is_melee else "ratk"
        
        # 1. 先查找针对特定攻击者类型的闪避音效
        try:
            vs_sounds = style.get(self.type_name, f"{prefix}_dodge_vs")
            if vs_sounds and len(vs_sounds) >= 2:
                target_type = vs_sounds[0]
                sound_id = vs_sounds[1]
                # 检查攻击者类型及其继承链
                if attacker_type == target_type or target_type in getattr(self, 'expanded_is_a', []):
                    return sound_id
        except:
            pass
        
        # 2. 再查找通用闪避音效
        try:
            s = style.get(self.type_name, f"{prefix}_dodge")
            if s:
                return random.choice(s)
        except:
            pass
        
        return None

    def on_missed(self, attacker_type, is_melee):
        """处理被打空事件"""
        # 将字符串转换为布尔值 - 更宽松的判断
        is_melee = str(is_melee).lower() in ('true', '1', 'yes')
        
        # 获取打空音效
        if is_melee:
            s = style.get(attacker_type, "matk_missed")  # 获取攻击者的近战落空音效
        else:
            s = style.get(attacker_type, "ratk_missed")  # 获取攻击者的远程落空音效
        
        if s:
            self.launch_event(random.choice(s))

    def on_exhausted(self):
        self.launch_event_style("exhausted")
        if "resource_exhausted" in config.verbosity:
            voice.info(self.title + mp.EXHAUSTED)

    def on_produced(self, resource_type, qty):
        """处理资源生产完成"""
        if self.player is not self.interface.player:
            return
            
        # 获取资源类型的本地化名称
        resource_title = style.get("parameters", f"{resource_type}_title")
        
        # 播放生产完成的提示音效
        self.launch_event_style("production", alert=True)
        
        # 发送通知消息
        if "resources_produced" in config.verbosity:
            voice.info(substitute_args(
                style.get("produced_%s" % resource_type, title="%s"),
                [qty]
            ))
            
        # 发送菜单更新通知
        self.interface.send_menu_alerts_if_needed()

    def on_completeness(self, s):  # building train or upgrade
        self.launch_event_style("production")
        self.launch_event_style("proportion_%s" % s)
        
        # 为资源生产进度添加语音提示
        if hasattr(self, "is_producing") and self.is_producing and s.isdigit():
            progress = int(s)
            if progress in [2, 5, 7]:  # 在20%, 50%, 70%的时候播放进度提示
                if "production_progress" in config.verbosity:
                    voice.info(mp.PRODUCTION + str(progress * 10) + mp.PERCENT)

    def on_complete(self):
        if self.player is not self.interface.player:
            return
        self.launch_event_style("complete", alert=True)
        if "unit_complete" in config.verbosity and must_be_said(self.number):
            voice.info(substitute_args(self.get_style("complete_msg"), [self.title]))
        self.interface.send_menu_alerts_if_needed()  # not necessary for "on_repair_complete" (if it existed)
        
    def on_resource_complete(self):
        """资源生产完成事件处理，只播放声音，不显示提示"""
        if self.player is not self.interface.player:
            return
        # 只播放声音，不显示提示信息
        self.launch_event_style("complete", alert=False)
        # 不需要调用send_menu_alerts_if_needed，避免菜单变化提示
        
    def on_research_complete(self):
        voice.info(self.get_style("research_complete_msg"))
        self.interface.send_menu_alerts_if_needed()

    def on_added(self):
        self.launch_event_style("added", alert=True)
        if "unit_added" in config.verbosity and must_be_said(self.number):
            voice.info(substitute_args(self.get_style("added_msg"), [self.ext_title]))
