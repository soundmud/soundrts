import copy

import re
from typing import Set

from .lib.defs import preprocess
from .lib.log import info, warning
from .lib.nofloat import PRECISION, to_int

VIRTUAL_TIME_INTERVAL = 300  # milliseconds
MAX_NB_OF_RESOURCE_TYPES = 10

def _get_base_classes():
    from .worldskill import Skill
    from .worldresource import Deposit
    from .worldunit import Worker, Soldier, Building, Effect
    from .worldupgrade import Upgrade

    return {
        "worker": Worker,
        "soldier": Soldier,
        "building": Building,
        "effect": Effect,
        "deposit": Deposit,
        "upgrade": Upgrade,
        "skill": Skill,  # 将 ability 改为 skill
    }


def _update_old_definitions(d, name):
    if "sight_range" in d and d["sight_range"] == 1 * PRECISION:
        d["sight_range"] = 12 * PRECISION
        d["bonus_height"] = 1
        info(
            "in %s: replacing sight_range 1 with sight_range 12 and bonus_height 1",
            name,
        )
    if "special_range" in d:
        del d["special_range"]
        d["range"] = 12 * PRECISION
        d["minimal_range"] = 4 * PRECISION
        d["is_ballistic"] = 1
        info(
            "in %s: replacing special_range 1 with range 12, minimal_range 4 and is_ballistic 1",
            name,
        )
    return d


class _Definitions:
    int_properties: Set[str] = set()
    precision_properties: Set[str] = set()
    int_list_properties: Set[str] = set()
    precision_list_properties: Set[str] = set()
    string_properties: Set[str] = set()

    def __init__(self):
        self._dict = {}

    def read(self, s):
        s = preprocess(s)
        d = self._dict
        name = "(the name is missing)"
        for line in s.split("\n"):
            try:
                words = line.split()
                if not words:
                    continue
                if words[0] == "clear":
                    d.clear()
                elif words[0] == "def":
                    name = words[1]
                    if name not in d:
                        d[name] = {}
                # 添加对 damage_seq 的特殊处理
                elif words[0] == "damage_seq":
                    # 解析攻击序列
                    seq_str = " ".join(words[1:])
                    match = re.search(r'(mdg|rdg)\s+(\d+)', seq_str)
                    if match:
                        damage_type = match.group(1)
                        # 检查基础伤害是否已定义
                        if damage_type not in d[name]:
                            warning(f"Base {damage_type} damage not defined for {name}")
                            continue
                            
                        requested_times = int(match.group(2))
                        
                        # 解析伤害序列
                        damage_match = re.search(r'\(damage\s+([0-9\s]+)\)', seq_str)
                        if damage_match:
                            # 先解析原始伤害值
                            raw_damages = [int(x) for x in damage_match.group(1).split()]
                            actual_times = len(raw_damages)
                            
                            # 检查序列长度与请求次数的关系
                            if actual_times > requested_times:
                                warning(f"Got {actual_times} damage values but only {requested_times} attacks requested - will truncate damage sequence")
                                raw_damages = raw_damages[:requested_times]  # 截断伤害序列
                                actual_times = requested_times
                            elif actual_times < requested_times:
                                warning(f"Requested {requested_times} attacks but got only {actual_times} damage values - will use actual damage sequence length")
                            
                            # 检查原始伤害总和是否等于基础伤害
                            base_damage = d[name][damage_type] // PRECISION  # 转换回原始值进行比较
                            if sum(raw_damages) == base_damage:
                                # 转换为精确值
                                damages = [x * PRECISION for x in raw_damages]
                                times = actual_times
                                
                                # 解析间隔时间
                                interval_match = re.search(r'\(interval\s+([\d\.]+)\)', seq_str)
                                interval = float(interval_match.group(1)) if interval_match else 0.0
                                
                                # 保存解析后的值
                                d[name][words[0]] = seq_str  # 保存原始字符串
                                d[name][f"{damage_type}_seq_times"] = times
                                d[name][f"{damage_type}_seq_damages"] = damages
                                d[name][f"{damage_type}_seq_interval"] = interval
                            else:
                                warning(f"Total sequence damage {sum(raw_damages)} does not match base damage {base_damage}")
                elif words[0] in self.string_properties:
                    d[name][words[0]] = words[1]
                elif words[0] in self.int_properties:
                    d[name][words[0]] = int(words[1])
                elif words[0] in self.precision_properties:
                    if words[0] == "effect_range" and len(words) >= 2:
                        if words[1] == "square":
                            words[1] = "6"
                            info(
                                "effect_range of %s will be 6 (instead of 'square')",
                                name,
                            )
                        elif words[1] == "nearby":
                            words[1] = "12"
                            info(
                                "effect_range of %s will be 12 (instead of 'nearby')",
                                name,
                            )
                        elif words[1] == "anywhere":
                            words[1] = "2147483"  # sys.maxint / 1000 (32 bits)
                    if len(words) >= 2 and words[1] == "inf":
                        words[1] = "2147483"  # sys.maxint / 1000 (32 bits)
                    d[name][words[0]] = to_int(words[1])
                elif words[0] in self.int_list_properties:
                    d[name][words[0]] = [int(x) for x in words[1:]]
                elif words[0] in self.precision_list_properties:
                    d[name][words[0]] = [to_int(x) for x in words[1:]]
                else:
                    if (words[0] == "effect" and words[1] == "bonus"):
                        # 处理多个属性-值对
                        processed_words = [words[0], words[1]]  # 保留 "effect bonus"
                        
                        # 从第三个词开始,每两个词为一组(属性和值)
                        for i in range(2, len(words), 2):
                            if i + 1 >= len(words):  # 确保有值
                                break
                                
                            stat = words[i]
                            value = words[i + 1]
                            
                            # 如果是精确属性,转换为整数
                            if stat in self.precision_properties:
                                try:
                                    value = to_int(value)
                                except ValueError:
                                    warning(f"Invalid value for {stat}: {value}")
                                    continue
                                    
                            processed_words.extend([stat, value])
                            
                        d[name][words[0]] = processed_words[1:]  # 存储处理后的结果
                    else:
                        d[name][words[0]] = words[1:]
            except Exception as e:
                warning("error in definition of %s: %s (%s)", name, line, str(e))

    def apply_inheritance(self, expanded_is_a=False):
        d = self._dict
        modified = True
        n = 0
        while modified:
            modified = False
            n += 1
            # for every object
            for ko, o in list(d.items()):
                if "is_a" in o:
                    # init "expanded_is_a" (first pass)
                    if expanded_is_a and "expanded_is_a" not in o:
                        o["expanded_is_a"] = o["is_a"][:]
                        modified = True
                    # for every parent
                    for p in o["is_a"]:
                        if p in d:
                            # for every attribute
                            for k, v in list(d[p].items()):
                                if expanded_is_a and k == "expanded_is_a":
                                    # add parents from "expanded_is_a" of parent
                                    # (if not yet in the object's "expanded_is_a")
                                    for is_a in v:
                                        if is_a not in o[k]:
                                            o[k] += [is_a]
                                            modified = True
                                elif k in d[p] and k not in o:
                                    # copy attribute from parent
                                    o[k] = v
                                    modified = True
                        else:
                            warning("error in %s.is_a: %s doesn't exist", ko, p)

    def _val(self, obj, attr):
        d = self._dict
        if obj not in d:
            return
        o = d[obj]
        if attr not in o:
            if "is_a" in o:
                for p in o["is_a"]:
                    if p in d and self._val(p, attr) is not None:
                        return self._val(p, attr)
            return
        return o[attr]

    def get(self, obj, attr, default=None):
        v = self._val(obj, attr)
        if v is None and attr[-8:-1] == "_level_":
            v = self._val(obj, attr[:-8])
        if isinstance(v, list):
            v = v[:]
        if v is None and default is not None:
            return default
        return v

    def get_dict(self, obj):
        return self._dict[obj]

    def classnames(self):
        return list(self._dict.keys())

    def copy(self, other):
        self.__dict__ = other.__dict__


_precision_properties = {
    "armor",
    "damage",
    "mdg",
    "rdg",
    "charge_mdg",
    "charge_rdg",
    "charge_mdg_range",
    "charge_rdg_range",
    "charge_mdg_minimal_range",
    "charge_rdg_minimal_range",
    "op_charge_mdg",
    "op_charge_rdg",
    "mdf",
    "rdf",
    "mdg_cd",
    "rdg_cd",
    "charge_mdg_cd",
    "charge_rdg_cd",
    "op_charge_mdg_cd",
    "op_charge_rdg_cd",
    "mdg_ready",
    "rdg_ready",
    "mdg_range",
    "rdg_range",
    "mdg_minimal_range",
    "rdg_minimal_range",
    "mdg_status_duration",
    "rdg_status_duration",
    "mdg_cover",
    "rdg_cover",
    "mdg_dodge",
    "rdg_dodge",
    "minimal_mdg",
    "minimal_rdg",
    "minimal_damage",
    "damage_radius",
    "mdg_radius",
    "rdg_radius",
    "mdg_splash",
    "rdg_splash",
        "mdg_delay",
        "rdg_delay",
        "mdg_blic",
        "rdg_blic",
    "range",
    "minimal_range",
    "decay",
    "qty",
    "extraction_qty",
    "hp_start",
    "hp_max",
    "hp_start",
    "mana_cost",
    "mana_max",
    "mana_start",
    "extraction_time",
    "time_cost",
    "cooldown",
    "hp_regen",
    "mana_regen",
    "speed",
    "effect_range",
    "effect_radius",
    "sight_range",
    "cloaking_range",
    "detection_range",
    "food_provided",  # 添加这一行
}
_precision_properties_extended = _precision_properties.union(
    s + "_bonus" for s in _precision_properties
)
assert "armor" in _precision_properties_extended
assert "armor_bonus" in _precision_properties_extended


class Rules(_Definitions):

    # 键值对属性集合
    key_value_properties = {
        "allow_units_add",     # 添加属性加成配置
    }

    string_properties = {
        "airground_type",
        "resource_type",  # 将resource_type从int_properties移到string_properties
        "production_type",  # 生产的资源类型
    }

    # 列表类属性
    string_list_properties = {
        "storable_resource_types",  # 添加这个新的属性集合
        "mdg_targets",
        "rdg_targets",
        "mdg_cover_on_terrain",
        "rdg_cover_on_terrain"
        "mdg_dodge_on_terrain",
        "rdg_dodge_on_terrain"
        "allow_units_attack",  # 允许攻击的单位列表
    }

    # vs属性集合
    vs_properties = {
        "mdg",
        "rdg",
        "mdf",
        "rdf",
        "mdg_range",
        "rdg_range",
        "mdg_cd",
        "rdg_cd",
        "mdg_cover",
        "rdg_cover",
        "mdg_dodge",
        "rdg_dodge",
    }

    def parse_unit_definition(self, type_name, attrs):
        """解析单位定义，支持灵活的继承机制
        支持以下格式:
        1. is_a footman(mdg rdf) - 继承指定的属性
        2. is_a footman(apart hp_max) - 继承除了指定属性外的其他属性
        3. is_a footman knight archer - 同时继承多个单位的所有属性
        4. is_a footman(mdg rdf) knight(hp_max) archer(apart rdg_range) - 混合继承
        """
        definition = {}
        
        # 处理所有非is_a属性
        for key, value in attrs:
            if key != "is_a":
                definition[key] = self.parse_property(key, value)
                
        # 处理is_a继承
        for key, value in attrs:
            if key == "is_a":
                parts = value.split()
                i = 0
                while i < len(parts):
                    source_name = parts[i]
                    included_attrs = set()
                    excluded_attrs = set()
                    
                    # 检查是否有括号指定属性
                    if i + 1 < len(parts) and parts[i + 1].startswith('('):
                        # 合并可能跨多个部分的括号内容
                        bracket_content = []
                        j = i + 1
                        while j < len(parts):
                            part = parts[j]
                            bracket_content.append(part.strip('()'))
                            if part.endswith(')'):
                                break
                            j += 1
                        if j < len(parts):  # 找到了完整的括号
                            attrs_str = ' '.join(bracket_content)
                            attrs_parts = attrs_str.split()
                            
                            # 处理apart关键字
                            if attrs_parts and attrs_parts[0] == 'apart':
                                excluded_attrs.update(attrs_parts[1:])
                            else:
                                included_attrs.update(attrs_parts)
                                
                            i = j + 1  # 跳过括号内容
                        else:
                            warning(f"Unclosed parenthesis in is_a definition for {source_name}")
                            i += 1
                    else:
                        i += 1
                        
                    # 应用继承
                    source_def = self.get(source_name)
                    if source_def:
                        for attr, val in source_def.items():
                            # 跳过特殊属性
                            if attr.startswith('_') or attr in ('type_name', 'is_a'):
                                continue
                                
                            # 如果指定了包含属性，只继承这些属性
                            if included_attrs and attr not in included_attrs:
                                continue
                                
                            # 如果指定了排除属性，不继承这些属性
                            if excluded_attrs and attr in excluded_attrs:
                                continue
                                
                            # 如果属性还未被设置，则继承它
                            if attr not in definition:
                                definition[attr] = copy.deepcopy(val)
                    else:
                        warning(f"Unknown unit type for inheritance: {source_name}")
                
        return definition

    def parse_upgrade_definition(self, type_name, attrs):
        """解析升级定义，支持继承机制"""
        definition = {"type_name": type_name, "expanded_is_a": set()}
        
        # 处理常规属性
        for key, value in attrs:
            if key != "is_a":
                definition[key] = self.parse_property(key, value)
                
        # 处理is_a继承
        for key, value in attrs:
            if key == "is_a":
                source_upgrades = value.split()
                definition["is_a"] = source_upgrades
                
                # 展开并记录所有继承关系
                for source_name in source_upgrades:
                    if source_name not in definition["expanded_is_a"]:
                        definition["expanded_is_a"].add(source_name)
                        source_def = self.get(source_name)
                        if source_def:
                            # 继承基类的expanded_is_a
                            if hasattr(source_def, "expanded_is_a"):
                                definition["expanded_is_a"].update(source_def.expanded_is_a)
                            # 继承其他属性
                            for attr, val in source_def.items():
                                if (not attr.startswith('_') and 
                                    attr not in ('type_name', 'is_a', 'expanded_is_a')):
                                    if attr not in definition:
                                        definition[attr] = copy.deepcopy(val)
                        else:
                            warning(f"Unknown upgrade type for inheritance: {source_name}")
                            
        return definition

    def parse_skill_definition(self, type_name, attrs):
        """解析技能定义，支持继承机制"""
        definition = {"type_name": type_name, "expanded_is_a": set()}
    
        # 处理常规属性
        for key, value in attrs:
            if key != "is_a":
                definition[key] = self.parse_property(key, value)
                
    # 处理is_a继承
        for key, value in attrs:
            if key == "is_a":
                source_skills = value.split()
                definition["is_a"] = source_skills
            
            # 展开并记录所有继承关系
                for source_name in source_skills:
                    if source_name not in definition["expanded_is_a"]:
                        definition["expanded_is_a"].add(source_name)
                        source_def = self.get(source_name)
                        if source_def:
                        # 继承基类的expanded_is_a
                            if hasattr(source_def, "expanded_is_a"):
                                definition["expanded_is_a"].update(source_def.expanded_is_a)
                        # 继承其他属性
                            for attr, val in source_def.items():
                                if (not attr.startswith('_') and 
                                    attr not in ('type_name', 'is_a', 'expanded_is_a')):
                                    if attr not in definition:
                                        definition[attr] = copy.deepcopy(val)
                        else:
                            warning(f"Unknown skill type for inheritance: {source_name}")
                            
        return definition

    def parse_definition(self, type_name, attrs):
        """根据类型选择合适的解析方法"""
        if type_name.startswith("summon_"):  # 对于召唤类技能
            return self.parse_skill_definition(type_name, attrs)
        elif any(attr[0] == "class" and attr[1] == "upgrade" for attr in attrs):
            return self.parse_upgrade_definition(type_name, attrs)
        else:
            return self.parse_unit_definition(type_name, attrs)


    def parse_property(self, key, value):
        """解析单个属性"""
        # 处理键值对属性
        if key in self.key_value_properties:
            result = {}
            if isinstance(value, str):
                items = value.split()
            else:
                items = value
            i = 0
            while i < len(items):
                if i + 1 >= len(items):
                    break
                try:
                    result[items[i]] = float(items[i + 1])
                    i += 2
                except (ValueError, IndexError):
                    i += 1
            return result
        # 处理其他类型的属性
        elif key in self.int_properties:
            return int(value)
        elif key in self.string_properties:
            return str(value)
        elif key in self.int_list_properties:
            return [int(x) for x in value.split()]
        elif key in self.string_list_properties:
            return value.split()
        else:
            return value

    def parse_upgrade_effect(self, effect_str):
        """解析升级效果
        effect_str 格式: "bonus stat1 value1 [stat2 value2 ...]"
        """
        try:
            parts = effect_str.split()
            if len(parts) < 3 or len(parts) % 2 != 1:
                raise ValueError(f"Invalid effect format: {effect_str}")
            
            effect_type = parts[0]
            
            # 验证所有属性-值对
            for i in range(1, len(parts), 2):
                if i + 1 >= len(parts):
                    raise ValueError(f"Missing value for attribute: {parts[i]}")
                    
                stat = parts[i]
                value = parts[i + 1]
                
                # 验证属性是否合法
                if not (stat in self.precision_properties or 
                       stat in self.string_list_properties or 
                       stat in self.int_properties or
                       stat.startswith("transport_")):
                    raise ValueError(f"Unknown attribute: {stat}")
                
                # 处理特殊值
                if stat == "effect_range" and value in ("square", "nearby", "anywhere"):
                    continue
                
                if value == "inf":
                    continue
                    
                # 根据属性类型验证值
                try:
                    if stat in self.precision_properties:
                        to_int(value)
                    elif stat in self.int_properties:
                        int(value)
                except ValueError:
                    raise ValueError(f"Invalid value for {stat}: {value}")
            
            return parts
            
        except Exception as e:
            warning(f"Error parsing upgrade effect: {str(e)}")
            raise

    def load_rules(self, filename):
        """加载规则文件"""
        with open(filename, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith(';'):
                    continue
                    
                if line.startswith('def '):
                    self._parse_definition(line[4:])

    int_properties = {
        "nb_of_resource_types",  # only in parameters
        "collision",
        "corpse",
        "food_cost",
        "food_provided",
        "harm_level",
        "heal_level",
        "is_repairable",
        "is_healable",
        "is_vulnerable",
        "is_undead",
        "is_a_building_land",
        "is_buildable_anywhere",
        "bonus_height",
        "transport_capacity",
        "transport_volume",
        "is_invisible",
        "is_cloakable",
        "is_a_detector",
        "is_a_cloaker",
        "universal_notification",
        "presence",
        "provides_survival",
        "is_ballistic",
                "is_teleportable",
        "is_a_gate",
        "is_buildable_on_exits_only",
        "is_buildable_near_water_only",
        "count_limit",
        "allow_attack_inside", # 允许攻击载具内部目标
        "capture_hp_threshold",  # 可被夺取的血量阈值(百分比,0表示不可夺取)
        "capture_cooldown",      # 夺取冷却时间(毫秒)
        "mdg_projectile",  # 近战攻击是否为投射物
        "rdg_projectile",  # 远程攻击是否为投射物
        "is_production",   # 建筑物是否可以生产资源
        "production_time",  # 生产时间
        "production_qty",   # 生产数量
    }
    precision_properties = _precision_properties_extended
    int_list_properties = {
    }
    precision_list_properties = {"cost", "storage_bonus", "production_cost"}

    def parse_resource_list(self, resource_list):
        """解析资源类型列表"""
        if not resource_list:
            return []
            
        result = []
        for resource in resource_list:
            index = self.parse_resource_type(resource)
            if index is not None:
                result.append(index)
                
        return result

    def get_property(self, classname, property_name, default=None):
        """重写get_property方法来处理资源类型列表"""
        value = super().get_property(classname, property_name, default)
        
        if property_name == "storable_resource_types" and value:
            return self.parse_resource_list(value)
            
        return value

    def parse_resource_type(self, resource_str):
        """
        将resource1、resource2等格式解析为对应的资源索引
        返回资源类型的索引(0-based)
        """
        if not resource_str:
            return None
            
        # 如果是数字,保持向后兼容
        if isinstance(resource_str, int) or resource_str.isdigit():
            return int(resource_str)
            
        # 解析resource{n}格式
        if resource_str.startswith('resource'):
            try:
                return int(resource_str[8:]) - 1  # resource1 -> 0
            except ValueError:
                return None
                
        return None


    def normalized_cost_or_resources(self, lst):
        lst = lst[:]
        n = self.get("parameters", "nb_of_resource_types", 2)
        while len(lst) < n:
            lst += [0]
        while len	(lst) > n:
            del lst[-1]
        return lst

    def interpret(self, d, base, name):
        if hasattr(base, "interpret"):
            base.interpret(d)
        if "cost" not in d and hasattr(base, "cost"):
            d["cost"] = [0] * self.get("parameters", "nb_of_resource_types", 2)
        d = _update_old_definitions(d, name)
        for k, v in list(d.items()):
            if k == "class":
                continue
            if (
                not hasattr(base, k)
                and not (k.endswith("_bonus") and hasattr(base, k[:-6]))
            ) or callable(getattr(base, k, None)):
                del d[k]
                warning(
                    "in %s: %s doesn't have any attribute called '%s'", name, base, k,
                )
            elif k == "cost":
                d[k] = self.normalized_cost_or_resources(v)

    def load(self, *strings, base_classes=None):
        if base_classes is None:
            base_classes = _get_base_classes()
        self._dict = {}
        for s in strings:
            s = re.sub(r"^[ \t]*class +race\b", "class faction", s, flags=re.M)
            self.read(s)
        self.apply_inheritance(expanded_is_a=True)
        d = {}
        for k, v in self._dict.items():
            cls = v.get("class", [None])[0]
            if cls in base_classes:
                base = base_classes[cls]
                self.interpret(v, base, k)
                d[k] = type(k, (base,), v)
                d[k].type_name = k
                d[k].cls = base
        self.classes = d

    def classnames(self):
        result = _Definitions.classnames(self)
        result.remove("parameters")
        return result

    @property
    def factions(self):
        return [c for c in self.classnames() if self.get(c, "class") == ["faction"]]

    def unit_class(self, s):
        """Get a custom unit class from its name.

        Example: unit_class("peasant") to get the peasant class

        At the moment, unit_classes contains also: upgrades, skills...
        """
        try:
            return self.classes[s]
        except KeyError:
            return

    def equivalent_type(self, t, faction):
        tn = getattr(t, "type_name", "")
        if rules.get(faction, tn):
            return self.unit_class(rules.get(faction, tn)[0])
        return t

    def _get_classnames(self, condition):
        result = []
        for c in self.classnames():
            uc = self.unit_class(c)
            if uc is not None and condition(uc):
                result.append(c)
        return result

    def get_makers(self, t):
        def can_make(uc, t):
            for a in ("can_build", "can_train", "can_upgrade_to", "can_research"):
                if t in getattr(uc, a, []):
                    return True
            for skill in getattr(uc, "can_use", []):
                effect = self.get(skill, "effect")
                if effect and "summon" in effect[:1] and t in effect:
                    return True

        if t.__class__ != str:
            t = t.__name__
        return self._get_classnames(lambda uc: can_make(uc, t))


def parse_noise(st):
    if st:
        if st[0] == "if_me":
            return "if_me", parse_noise(st[1]), parse_noise(st[2])
        ambient = st[0] == "ambient"
        if ambient:
            st = st[1:]
        t = st[0]
        if t == "loop":
            try:
                v = float(st[2])
            except IndexError:
                v = 1
            return "loop", st[1], v, ambient
        if t == "repeat":
            return "repeat", float(st[1]), st[2:], ambient
    return ()


class Style(_Definitions):
    def __init__(self):
        self._style_warnings = []

    def load(self, *strings):
        self._dict = {}
        for s in strings:
            self.read(s)
        for d in self._dict.values():
            for k, v in d.items():
                if v and v[0] == "if_me":
                    if "else" in v:
                        i = v.index("else")
                        v = "if_me", v[1:i], v[i + 1:]
                    else:
                        v = "if_me", v[1:], []
                if k.startswith("noise"):
                    try:
                        v = parse_noise(v)
                    except:
                        warning("problem with noise: %s", " ".join(d[k]))
                d[k] = v
        self.apply_inheritance()

    def get(self, obj, attr, warn_if_not_found=True):
        result = _Definitions.get(self, obj, attr)
        if result is None:
            result = []  # the caller might expect a list
            if warn_if_not_found:
                # 忽略已经被新系统替代的属性
                deprecated_attrs = {
                    'missed',  # 已被 dodge 系统替代
                }
                
                if attr not in deprecated_attrs:
                    if (obj, attr) not in self._style_warnings:
                        self._style_warnings.append((obj, attr))
                        warning("no value found for %s.%s (check style.txt)", obj, attr)
        return result

    def has(self, obj, attr):
        return _Definitions.get(self, obj, attr) is not None


# AI (probably completely separate)


def _read_ai_to_dict(s, d):
    s = preprocess(s)
    name = None
    for line in s.split("\n"):
        words = line.split()
        if not words:
            continue
        if words[0] == "def":
            name = words[1]
            d[name] = []
        elif name is not None:
            d[name] += [line]
        else:
            warning("'def <AI_name>' is missing (check ai.txt)")


_ai = {}


def load_ai(*strings):
    global _ai
    _ai = {}
    for s in strings:
        _read_ai_to_dict(s, _ai)


def get_ai(name):
    return _ai[name]


def get_ai_names():
    return list(_ai.keys())


# define two convenient variables

rules = Rules()
style = Style()
