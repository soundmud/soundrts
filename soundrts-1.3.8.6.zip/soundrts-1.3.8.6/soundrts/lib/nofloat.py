""""use integers to make sure that any computer will give the same results"""

import math
from typing import Dict, List, Tuple
from .log import warning

PRECISION = 1000
MAP_SIZE = 1000  # 地图大小，单位为格子数

# tables used to make sure that every computer gives the same results

class TrigTables:
    """三角函数查找表生成器"""
    
    @staticmethod
    def generate_cos_table(precision: int = PRECISION) -> Tuple[int, ...]:
        """生成余弦查找表"""
        return tuple(
            int(math.cos(math.radians(a)) * precision)
            for a in range(360)
        )
    
    @staticmethod
    def generate_sin_table(precision: int = PRECISION) -> Tuple[int, ...]:
        """生成正弦查找表"""
        return tuple(
            int(math.sin(math.radians(a)) * precision)
            for a in range(360)
        )
    
    @staticmethod
    def generate_acos_table(precision: int = 100) -> Dict[int, int]:
        """生成反余弦查找表"""
        return {
            c: int(math.degrees(math.acos(c / precision)))
            for c in range(-precision, precision + 1)
        }
    
    @classmethod
    def generate_all(cls) -> str:
        """生成所有查找表的代码字符串"""
        cos_table = cls.generate_cos_table()
        sin_table = cls.generate_sin_table()
        acos_table = cls.generate_acos_table()
        
        return f"""
# Auto-generated trigonometric tables
_COS_TABLE = {cos_table}
_SIN_TABLE = {sin_table}
_ACOS_TABLE = {acos_table}
"""

def make_tables():
    """生成查找表代码并打印"""
    print(TrigTables.generate_all())

# 使用生成的表替换原有的硬编码表
_COS_TABLE = TrigTables.generate_cos_table()
_SIN_TABLE = TrigTables.generate_sin_table() 
_ACOS_TABLE = TrigTables.generate_acos_table()

def to_int(s) -> int:
    """将字符串转换为整数，失败时返回0"""
    try:
        return int(float(s))
    except (ValueError, TypeError):
        return 0


def to_int(s):
    """convert a string to an integer with PRECISION"""
    assert isinstance(s, str)  # don't convert twice!
    result = int(float(s) * PRECISION)
    return result


def int_cos_1000(angle):
    """angle in degrees; result = cos(angle) * 1000"""
    assert isinstance(angle, int)
    return _COS_TABLE[angle % 360]


def int_sin_1000(angle):
    """angle in degrees; result = sin(angle) * 1000"""
    assert isinstance(angle, int)
    return _SIN_TABLE[angle % 360]


def square_of_distance(x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    return dx * dx + dy * dy


def int_distance(x1, y1, x2, y2):
    return int_sqrt(square_of_distance(x1, y1, x2, y2))


def int_sqrt(x):
    """should return the same integer square root on any computer"""
    r = int(math.sqrt(x))
    while r * r > x:
        warning(f"sqrt({x}): removing 1 to {r}")
        r -= 1
    while (r + 1) * (r + 1) < x:
        warning(f"sqrt({x}): adding 1 to {r}")
        r += 1
    return r


def int_angle(x1, y1, x2, y2):
    """return the angle with the x-axis (in degrees)"""
    d = int_distance(x1, y1, x2, y2)
    if d == 0:
        return 0
    c = (x2 - x1) * 100 // d  # 100 for the table
    ac = _ACOS_TABLE[c]
    if y2 - y1 > 0:
        return ac
    else:
        return -ac
