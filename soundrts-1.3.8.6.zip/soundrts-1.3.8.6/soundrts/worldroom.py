import string
from functools import lru_cache

from .definitions import rules, style
from .lib.log import warning
from .lib.msgs import nb2msg
from .lib.nofloat import int_angle, int_cos_1000, int_distance, int_sin_1000
from .lib.priodict import priorityDictionary
from .worldentity import COLLISION_RADIUS
from .worldexit import passage
from .worldresource import Deposit, Meadow

SPACE_LIMIT = 144


def square_spiral(x, y, step=COLLISION_RADIUS * 25 // 10):
    yield x, y
    sign = 1
    delta = 1
    while delta < 25:
        for _ in range(delta):
            x += sign * step
            yield x, y
        for _ in range(delta):
            y += sign * step
            yield x, y
        delta += 1
        sign *= -1


_cache = {}
_cache_time = None


def cache(f):
    def decorated_f(*args, **kargs):
        global _cache, _cache_time
        if _cache_time != args[0].world.time:
            _cache = {}
            _cache_time = args[0].world.time
        k = (args, tuple(sorted(kargs.items())))
        if k not in _cache:
            _cache[k] = f(*args, **kargs)
        return _cache[k]

    return decorated_f


class _Space:
    high_ground = False

    def __init__(self):
        self.objects = []

    def enter(self, o):
        self.objects.append(o)
        if o.id is None:
            self.world.register_entity(o)

    def leave(self, o):
        self.objects.remove(o)


class QuadTree:
    """四叉树实现,用于空间划分和快速区域查询"""
    
    def __init__(self, boundary, max_objects=4, max_depth=6):
        self.boundary = boundary  # (xmin, ymin, xmax, ymax)
        self.max_objects = max_objects
        self.max_depth = max_depth
        self.objects = []
        self.divided = False
        self.nw = None
        self.ne = None
        self.sw = None
        self.se = None
        self.depth = 0
        
    def subdivide(self):
        """将节点分为四个子节点"""
        xmin, ymin, xmax, ymax = self.boundary
        xmid = (xmin + xmax) // 2
        ymid = (ymin + ymax) // 2
        
        # 创建四个子节点
        self.nw = QuadTree((xmin, ymid, xmid, ymax), self.max_objects, self.max_depth)
        self.ne = QuadTree((xmid, ymid, xmax, ymax), self.max_objects, self.max_depth)
        self.sw = QuadTree((xmin, ymin, xmid, ymid), self.max_objects, self.max_depth)
        self.se = QuadTree((xmid, ymin, xmax, ymid), self.max_objects, self.max_depth)
        
        # 设置子节点深度
        for child in (self.nw, self.ne, self.sw, self.se):
            child.depth = self.depth + 1
            
        self.divided = True
        
    def insert(self, obj):
        """插入对象到四叉树"""
        # 如果对象不在边界内,返回False
        if not self._in_boundary(obj):
            return False
            
        # 如果没有达到对象数量限制且未划分
        if len(self.objects) < self.max_objects and not self.divided:
            self.objects.append(obj)
            return True
            
        # 如果需要划分且未达到最大深度
        if not self.divided and self.depth < self.max_depth:
            self.subdivide()
            
            # 重新分配现有对象
            objects = self.objects
            self.objects = []
            for existing_obj in objects:
                self._insert_to_children(existing_obj)
                
        # 尝试插入到子节点
        if self.divided:
            return self._insert_to_children(obj)
            
        # 如果已达到最大深度,添加到当前节点
        self.objects.append(obj)
        return True
        
    def _insert_to_children(self, obj):
        """将对象插入到合适的子节点"""
        if self.nw.insert(obj): return True
        if self.ne.insert(obj): return True
        if self.sw.insert(obj): return True
        if self.se.insert(obj): return True
        return False
        
    def _in_boundary(self, obj):
        """检查对象是否在边界内"""
        xmin, ymin, xmax, ymax = self.boundary
        return (xmin <= obj.x < xmax and 
                ymin <= obj.y < ymax)
                
    def query_range(self, range_boundary):
        """查询指定范围内的所有对象"""
        found_objects = []
        
        # 如果查询范围与当前节点边界不相交,返回空列表
        if not self._intersects_boundary(range_boundary):
            return found_objects
            
        # 添加当前节点中的对象(如果在查询范围内)
        for obj in self.objects:
            if self._object_in_range(obj, range_boundary):
                found_objects.append(obj)
                
        # 如果已划分,递归查询子节点
        if self.divided:
            found_objects.extend(self.nw.query_range(range_boundary))
            found_objects.extend(self.ne.query_range(range_boundary))
            found_objects.extend(self.sw.query_range(range_boundary))
            found_objects.extend(self.se.query_range(range_boundary))
            
        return found_objects
        
    def _intersects_boundary(self, range_boundary):
        """检查两个边界是否相交"""
        xmin1, ymin1, xmax1, ymax1 = self.boundary
        xmin2, ymin2, xmax2, ymax2 = range_boundary
        return not (xmax1 < xmin2 or xmax2 < xmin1 or
                   ymax1 < ymin2 or ymax2 < ymin1)
                   
    def _object_in_range(self, obj, range_boundary):
        """检查对象是否在指定范围内"""
        xmin, ymin, xmax, ymax = range_boundary
        return (xmin <= obj.x < xmax and 
                ymin <= obj.y < ymax)


class Square(_Space):

    transport_capacity = 0
    type_name = ""
    terrain_speed = (100, 100)
    terrain_cover = (0, 0)
    is_ground = True
    is_water = False
    is_air = True

    def __init__(self, world, col, row, width):
        super().__init__()
        self.col = col
        self.row = row
        self.name = "{}{}".format(string.ascii_lowercase[col], row + 1)
        self.id = world.get_next_id()
        self.world = world
        world.squares.append(self)
        world.objects[self.id] = self
        self.place = world
        self.title = [5000 + col] + nb2msg(row + 1)
        self.exits = []
        self.xmin = col * width
        self.ymin = row * width
        self.xmax = self.xmin + width
        self.ymax = self.ymin + width
        self.x = (self.xmax + self.xmin) // 2
        self.y = (self.ymax + self.ymin) // 2

    def __repr__(self):
        return "<'%s'>" % self.name

    @property
    def height(self):
        if self.high_ground:
            return 1
        else:
            return 0

    @property
    @lru_cache()
    def strict_neighbors(self):
        result = []
        for dc, dr in ((0, 1), (0, -1), (1, 0), (-1, 0)):
            s = self.world.grid.get((self.col + dc, self.row + dr))
            if s is not None:
                result.append(s)
        return result

    @property
    @lru_cache()
    def neighbors(self):
        result = []
        for dc, dr in (
            (0, 1),
            (0, -1),
            (1, 0),
            (-1, 0),
            (1, 1),
            (1, -1),
            (-1, 1),
            (-1, -1),
        ):
            s = self.world.grid.get((self.col + dc, self.row + dr))
            if s is not None:
                result.append(s)
        return result

    @property
    def building_land(self):
        for o in self.objects:
            if o.is_a_building_land:
                return o

    @property
    def exit(self):
        for o in self.exits:
            if o.is_an_exit and not o.is_blocked():
                return o

    @property
    def subsquares(self):
        k = (self.xmax - self.xmin) // 3
        for dx in [0, 1, -1]:
            for dy in [0, 1, -1]:
                yield ZoomTarget(self, self.x + dx * k, self.y + dy * k)

    @property
    def any_land(self):
        for s in self.subsquares:
            if s.any_land:
                return s

    @property
    def is_near_water(self):
        if not self.is_ground or self.high_ground:
            return False
        for sq in self.strict_neighbors:
            if sq.is_water:
                return True

    def __getstate__(self):
        d = self.__dict__.copy()
        if "spiral" in d:
            del d["spiral"]
        return d

    def is_near(self, square):  # FIXME: not used (remove?)
        try:
            return (abs(self.col - square.col), abs(self.row - square.row)) in (
                (0, 1),
                (1, 0),
                (1, 1),
            )
        except AttributeError:  # not a square
            return False

    def clean(self):
        for o in self.objects:
            o.clean()
        self.__dict__ = {}

    def contains(self, x, y):
        return self.xmin <= x < self.xmax and self.ymin <= y < self.ymax

    def shortest_path_to(
        self, dest, player=None, plane="ground", places=False, avoid=False
    ):
        if places:
            return self._shortest_path_to(dest, plane, player, places=True, avoid=avoid)
        else:
            return self._shortest_path_to(dest, plane, player, avoid=avoid)[0]

    def shortest_path_distance_to(self, dest, player=None, plane="ground", avoid=False):
        return self._shortest_path_to(dest, plane, player, avoid=avoid)[1]

    @cache
    def _heuristic(self, node, goal):
        """A* heuristic function to estimate distance between nodes"""
        return int_distance(node.x, node.y, goal.x, goal.y)

    def _build_quadtree(self):
        """构建四叉树"""
        # 创建覆盖整个区域的四叉树
        quadtree = QuadTree((self.xmin, self.ymin, self.xmax, self.ymax))
        
        # 插入所有出口和障碍物
        for exit in self.exits:
            quadtree.insert(exit)
        
        # 插入其他需要考虑的对象
        for obj in self.objects:
            if obj.collision:  # 只插入会造成碰撞的对象
                quadtree.insert(obj)
                
        return quadtree

    @cache
    def _shortest_path_to(self, dest, plane, player, places=False, avoid=False):
        """A*寻路算法实现"""
        if avoid:
            avoid = player.is_very_dangerous
        else:
            avoid = lambda x: False
            
        if dest is self:
            return [self] if places else (None, 0)

        # 添加起点和终点到图
        G = self.world.g[plane]
        if plane == "ground":
            for v in (self, dest):
                G[v] = {}
                for e in v.exits:
                    G[v][e] = G[e][v] = int_distance(v.x, v.y, e.x, e.y)
        
        start = self
        end = dest

        # A*算法数据结构
        closed_set = set()
        open_set = {start}
        came_from = {}
        
        g_score = {start: 0}  # 从起点到当前节点的实际代价
        f_score = {start: self._heuristic(start, end)}  # 估计的总代价
        
        while open_set:
            # 获取f_score最小的节点
            current = min(open_set, key=lambda x: f_score.get(x, float('inf')))
            
            if current == end:
                # 重建路径
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(start)
                path.reverse()
                
                # 恢复图
                if plane == "ground":
                    for v in (start, end):
                        del G[v]
                        for e in v.exits:
                            del G[e][v]
                
                if places:
                    return [e.place for e in path if hasattr(e, "other_side")]
                else:
                    return path[1], g_score[end]
            
            open_set.remove(current)
            closed_set.add(current)
            
            # 检查所有相邻节点
            for neighbor in G[current]:
                # 检查是否被阻挡
                if (hasattr(neighbor, "is_blocked") and 
                    neighbor.is_blocked(player, ignore_enemy_walls=True) or 
                    avoid(neighbor)):
                    continue
                    
                if neighbor in closed_set:
                    continue
                    
                # 计算通过当前节点到达邻居节点的代价
                tentative_g_score = g_score[current] + G[current][neighbor]
                
                if neighbor not in open_set:
                    open_set.add(neighbor)
                elif tentative_g_score >= g_score.get(neighbor, float('inf')):
                    continue
                    
                # 这是到达neighbor的最佳路径
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g_score
                f_score[neighbor] = g_score[neighbor] + self._heuristic(neighbor, end)
        
        # 没有找到路径
        if plane == "ground":
            for v in (start, end):
                del G[v]
                for e in v.exits:
                    del G[e][v]
                    
        return [] if places else (None, float('inf'))

    def find_nearest_meadow(self, unit):
        def _d(o):
            # o.id to make sure that the result is the same on any computer
            return int_distance(o.x, o.y, unit.x, unit.y), o.id

        meadows = sorted([o for o in self.objects if isinstance(o, Meadow)], key=_d)
        if meadows:
            return meadows[0]

    def find_and_remove_meadow(self, item_type):
        if item_type.is_buildable_anywhere:
            return self.x, self.y, None
        for o in self.objects:
            if isinstance(o, Meadow):
                x, y = o.x, o.y
                o.delete()
                return x, y, o
        return self.x, self.y, None

    def contains_enemy(self, player):
        for o in self.objects:
            if player.is_an_enemy(o):
                return True
        return False

    def north_side(self):
        return self, self.x, self.ymax - 1, -90

    def south_side(self):
        return self, self.x, self.ymin, 90

    def east_side(self):
        return self, self.xmax - 1, self.y, 180

    def west_side(self):
        return self, self.xmin, self.y, 0

    def _shift(self, xc, yc):
        # shift angle to have central symmetry and map balance
        # (distance from the townhall to the resources)
        return int_angle(xc, yc, self.col * 10 + 5, self.row * 10 + 5)

    def arrange_resources_symmetrically(self, xc, yc):
        things = [o for o in self.objects if isinstance(o, (Deposit, Meadow))]
        square_width = self.xmax - self.xmin
        nb = len(things)
        shift = self._shift(xc, yc)
        for i, o in enumerate(things):
            x = self.x
            y = self.y
            if nb > 1:
                a = 360 * i // nb + shift
                # it is possible to add a constant to this angle and keep
                # the symmetry
                x += square_width * 35 // 100 * int_cos_1000(a) // 1000
                y += square_width * 35 // 100 * int_sin_1000(a) // 1000
            o.move_to(o.place, x, y)

    def can_receive(self, airground_type, player=None):
        if player is not None:
            f = player.is_an_enemy
        else:
            f = lambda x: False
        return (
            len(
                [
                    u
                    for u in self.objects
                    if u.collision and u.airground_type == airground_type and not f(u)
                ]
            )
            < SPACE_LIMIT
        )

    def find_free_space(self, airground_type, x, y):
        # assertion: object has collision
        if self.contains(x, y) and not self.world.collision[
            airground_type
        ].would_collide(x, y):
            return x, y
        if self.world.time == 0 and (x, y) == (self.x, self.y):
            if not hasattr(self, "spiral"):
                self.spiral = {}
                self.spiral["ground"] = square_spiral(x, y)
                self.spiral["air"] = square_spiral(x, y)
                self.spiral["water"] = square_spiral(x, y)
            spiral = self.spiral[
                airground_type
            ]  # reuse spiral (don't retry used places: much faster!)
        else:
            spiral = square_spiral(x, y)
        for x, y in spiral:
            if self.contains(x, y) and not self.world.collision[
                airground_type
            ].would_collide(x, y):
                return x, y
        return None, None

    def find_free_space_for(self, o, x, y):
        o.free_space()
        x, y = self.find_free_space(o.airground_type, x, y)
        o.occupy_space()
        return x, y

    def add(self, o):
        self.world.collision[o.airground_type].add(o.x, o.y)

    def remove(self, o):
        self.world.collision[o.airground_type].remove(o.x, o.y)

    def would_collide(self, o, x, y):
        space = self.world.collision[o.airground_type]
        space.remove(o.x, o.y)
        result = space.would_collide(x, y)
        space.add(o.x, o.y)
        return result

    def ensure_path(self, other):
        if other not in [e.other_side.place for e in self.exits]:
            x = (self.x + other.x) // 2
            y = (self.y + other.y) // 2
            passage(((self, x, y, 0), (other, x, y, 0), False), "path")
            self.world._create_graphs()

    def ensure_nopath(self, other):
        for e in self.exits:
            if other == e.other_side.place:
                e.delete()

    def ensure_free_path(self, other):
        for e in self.exits:
            if other == e.other_side.place:
                e.is_blocked_by_forests = False

    def ensure_blocked_path(self, other):
        for e in self.exits:
            if other == e.other_side.place:
                e.is_blocked_by_forests = True

    def toggle_path(self, dc, dr):
        other = self.world.grid.get((self.col + dc, self.row + dr))
        if not other:  # border
            return
        if other in [e.other_side.place for e in self.exits]:
            self.ensure_nopath(other)
        else:
            self.ensure_path(other)
            return True

    def ensure_meadows(self, n):
        for o in self.objects[:]:
            if n >= self.nb_meadows:
                break
            if o.is_a_building_land and not getattr(o, "is_an_exit", False):
                o.delete()
        for _ in range(n - self.nb_meadows):
            Meadow(self)
        self.arrange_resources_symmetrically(self.x, self.y)

    def ensure_resources(self, t, n, q):
        for o in self.objects[:]:
            if o.type_name == t:
                o.delete()
        for _ in range(n):
            rules.unit_class(t)(self, q)

    @property
    def nb_meadows(self):
        return len(
            [
                o
                for o in self.objects
                if o.is_a_building_land
                and not getattr(o, "is_an_exit", False)
                or o.building_land
                and not getattr(o, "qty", 0)
            ]
        )

    def update_terrain(self):
        meadows = len([o for o in self.objects if o.type_name == "meadow"])
        woods = len([o for o in self.objects if o.type_name == "wood"])
        if woods >= 7:
            self.type_name = "_dense_forest"
        elif woods:
            self.type_name = "_forest"
        elif meadows:
            self.type_name = "_meadows"
        else:
            self.type_name = ""
        # dynamic path through forest
        if self.type_name == "_dense_forest":
            for s in self.strict_neighbors:
                if s.type_name == "_dense_forest":
                    self.ensure_blocked_path(s)
                else:
                    self.ensure_free_path(s)
        else:
            for s in self.strict_neighbors:
                self.ensure_free_path(s)


class Inside(_Space):
    container = None
    neighbors = []
    is_ground = True
    place = None
    id = None
    exits = []  # 添加空的 exits 列表

    def __init__(self, container):
        super().__init__()
        self.container = container

    @property
    def title(self):
        return style.get(self.container.type_name, "title")

    @property
    def high_ground(self):
        if self.container.airground_type == "air":
            return True
        return self.container.place.high_ground

    @property
    def height(self):
        return self.container.height

    @property
    def world(self):
        return self.container.world

    @property
    def outside(self):
        return self.container.place

    def have_enough_space(self, new_object):
        capacity = self.container.transport_capacity
        for o in self.objects:
            capacity -= o.transport_volume
        return capacity >= new_object.transport_volume

    def find_free_space_for(self, o, x, y):
        return x, y

    def add(self, o):
        return

    def remove(self, o):
        return

    def update(self):
        for o in self.objects:
            o.x = self.container.x
            o.y = self.container.y
            o.update()


class ZoomTarget:

    collision = 0
    radius = 0

    def __init__(self, place, x, y, id=None):
        self.place = place
        self.x = x
        self.y = y
        self.id = id
        self.title = self.place.title  # TODO: full zoom title

    def __eq__(self, other):
        if isinstance(other, ZoomTarget):
            return self.x, self.y == other.x, other.y

    def __ne__(self, other):
        return not self.__eq__(other)

    @property
    def building_land(self):
        for o in self.place.objects:
            if o.is_a_building_land and self.contains(o.x, o.y):
                return o

    @property
    def exit(self):
        for o in self.place.exits:
            if not o.is_blocked() and self.contains(o.x, o.y):
                return o

    @property
    def any_land(self):
        for o in self.place.objects:
            if getattr(o, "is_buildable_anywhere", False) and self.contains(o.x, o.y):
                return
        return self

    def contains(self, x, y):
        subsquare = self.place.world.get_subsquare_id_from_xy
        return subsquare(self.x, self.y) == subsquare(x, y)
