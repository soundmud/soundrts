from soundrts.lib.nofloat import PRECISION

from .definitions import MAX_NB_OF_RESOURCE_TYPES


class Skill:  # or UnitOption or UnitMenuItem or ActiveSkill or SpecialSkill

    cost = (0,) * MAX_NB_OF_RESOURCE_TYPES  # required by the user interface
    count_limit = 0  # ugly but necessary; used by ComplexOrder.is_allowed()
    time_cost = 0  # doesn't seem to be required
    requirements = ()
    food_cost = 0
    mana_cost = 0
    effect = None
    effect_target = ["self"]
    effect_range = 6 * PRECISION  # "square"
    effect_radius = 6 * PRECISION
    universal_notification = False
    is_a = ()  # 添加is_a支持
    expanded_is_a = set()  # 添加expanded_is_a支持

    cls = object  # probably not used

    def __init__(self):
        # 初始化expanded_is_a
        self.expanded_is_a = set()
        if hasattr(self, 'is_a'):
            self._expand_is_a(self.is_a)
    
    def _expand_is_a(self, is_a_list):
        """展开并记录所有继承关系"""
        if not is_a_list:
            return
            
        for base_type in is_a_list:
            if base_type not in self.expanded_is_a:
                self.expanded_is_a.add(base_type)
                # 递归处理基类的继承
                base_class = rules.get(base_type)
                if base_class and hasattr(base_class, 'is_a'):
                    self._expand_is_a(base_class.is_a)

    # 新增方法来检查释放条件
    @classmethod
    def check_cast_requirements(cls, unit):
        # 检查法力消耗
        if cls.mana_cost and unit.mana < cls.mana_cost:
            return False, "not_enough_mana"
            
        # 检查资源消耗
        if any(cls.cost):
            result = unit.player.check_if_enough_resources(cls.cost)
            if result is not None:
                return False, result
                
        return True, None