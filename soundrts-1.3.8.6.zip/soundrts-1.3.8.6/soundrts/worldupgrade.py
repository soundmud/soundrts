import copy
from .definitions import MAX_NB_OF_RESOURCE_TYPES, rules
from .lib.nofloat import PRECISION


def is_an_upgrade(o):
    return hasattr(o, "upgrade_player")


class Upgrade:
    """升级系统基类"""
    cost = (0,) * MAX_NB_OF_RESOURCE_TYPES
    count_limit = 0
    time_cost = 0
    requirements = ()
    food_cost = 0
    effect = None
    is_a = ()  # 添加is_a支持
    expanded_is_a = set()  # 添加expanded_is_a支持

    def __init__(self):
        # 初始化expanded_is_a
        self.expanded_is_a = set()
        if hasattr(self, 'is_a'):
            self._expand_is_a(self.is_a)
    
    def _expand_is_a(self, is_a_list):
        """展开并记录所有继承关系"""
        if not is_a_list:
            return
            
        for base_type in is_a_list:
            if base_type not in self.expanded_is_a:
                self.expanded_is_a.add(base_type)
                # 递归处理基类的继承
                base_class = rules.get(base_type)
                if base_class and hasattr(base_class, 'is_a'):
                    self._expand_is_a(base_class.is_a)

    @classmethod
    def upgrade_player(cls, player):
        """为玩家应用升级效果"""
        for unit in player.units:
            if cls.type_name in unit.can_use:
                # 处理effect
                if not cls.effect:
                    continue
                
                # 将effect转换为列表（如果是字符串的话）
                if isinstance(cls.effect, str):
                    effect_parts = cls.effect.split()
                else:
                    effect_parts = list(cls.effect)
                
                # 获取效果类型
                effect_type = effect_parts[0]
                if not effect_type.startswith('effect_'):
                    effect_type = 'effect_' + effect_type
                
                # 处理剩余参数
                effect_args = effect_parts[1:]
                
                # 检查是否有对应的处理方法
                if hasattr(cls, effect_type):
                    try:
                        # 调用对应的效果处理方法
                        getattr(cls, effect_type)(
                            unit, player.level(cls.type_name), *effect_args
                        )
                    except Exception as e:
                        from .lib.log import warning
                        warning(f"Error applying effect {effect_type} to {unit}: {str(e)}")
                        continue
                    
        player.upgrades.append(cls.type_name)

    @classmethod
    def upgrade_unit_to_player_level(cls, unit):
        """将单位升级到玩家的科技等级"""
        for level in range(unit.player.level(cls.type_name)):
            if isinstance(cls.effect, str):
                # 处理整个效果字符串
                effect_parts = cls.effect.split()
                effect_type = effect_parts[0]
                effect_args = effect_parts[1:]
                if not effect_type.startswith('effect_'):
                    effect_type = 'effect_' + effect_type
                if hasattr(cls, effect_type):
                    getattr(cls, effect_type)(unit, level, *effect_args)
            elif isinstance(cls.effect, list):
                for effect in cls.effect:
                    if isinstance(effect, str):
                        effect_parts = effect.split()
                        effect_type = effect_parts[0]
                        effect_args = effect_parts[1:]
                    elif isinstance(effect, (list, tuple)):
                        effect_type = effect[0]
                        effect_args = effect[1:]
                    else:
                        continue
                        
                    if not effect_type.startswith('effect_'):
                        effect_type = 'effect_' + effect_type
                    if hasattr(cls, effect_type):
                        getattr(cls, effect_type)(unit, level, *effect_args)

    @classmethod
    def effect_bonus(cls, unit, start_level, *args):
        """通用属性加成处理器
        支持多个属性参数和资源消耗的解析
        格式: effect bonus stat1 value1 stat2 value2 ...
        """
        # 必须使用整数的属性集合
        integer_stats = {'hp', 'hp_max', 'minimal_damage', 'food_cost', 'time_cost'}
        
        i = 0
        while i < len(args):
            stat = args[i]
            value = args[i + 1]
            
            # 处理 is_a 继承
            if stat == "is_a":
                # ... [保持原有的is_a处理代码] ...
                continue
            
            # 处理资源消耗修正
            if stat == "cost":
                # ... [保持原有的cost处理代码] ...
                i += 2
                continue
                
            # 处理运输相关属性
            if stat.startswith("transport_"):
                # ... [保持原有的transport处理代码] ...
                i += 2
                continue
                
            # 处理攻击目标类型
            if stat.endswith("_targets"):
                # ... [保持原有的targets处理代码] ...
                i += 2
                continue
                
            # 处理近战和远程伤害属性
            if stat in ("mdg", "rdg"):
                # 基础属性使用整数
                current = getattr(unit, stat, 0)
                new_value = current + int(float(value))
                setattr(unit, stat, new_value)
                
                # 等级属性使用整数
                level_stat = f"{stat}_level"
                if not hasattr(unit, level_stat):
                    setattr(unit, level_stat, 0)
                current_level = getattr(unit, level_stat)
                setattr(unit, level_stat, current_level + 1)
                
                # vs属性也使用整数
                vs_stat = f"{stat}_vs"
                if hasattr(unit, vs_stat):
                    vs_dict = getattr(unit, vs_stat)
                    for target_type in vs_dict:
                        vs_dict[target_type] += int(float(value))
                
                i += 2
                continue
                
            # 处理普通数值属性
            current = getattr(unit, stat, 0)
            try:
                if stat in integer_stats:  # 必须使用整数的属性
                    setattr(unit, stat, current + int(float(value)))
                else:
                    value_float = float(value)
                    setattr(unit, stat, current + value_float)
            except ValueError:
                # 如果转换失败，尝试使用int
                setattr(unit, stat, current + int(value))
            
            i += 2

    @classmethod
    def effect_apply_bonus(cls, unit, start_level, *stats):
        """应用多个属性的bonus值
        格式: effect apply_bonus stat1 stat2 stat3 ...
        支持多级升级的bonus值，例如：
        sight_range_bonus 1 1 1  # 三级升级各加1
        rdg_bonus 1 2 6         # 三级升级分别加1,2,6
        """
        for stat in stats:
            # 处理目标类型
            if stat.endswith("_targets"):
                targets_bonus = f"{stat}_bonus"
                if hasattr(unit, targets_bonus):
                    targets = getattr(unit, targets_bonus)
                    if isinstance(targets, (list, tuple)):
                        current_targets = getattr(unit, stat, [])
                        for target in targets:
                            if target not in current_targets:
                                current_targets.append(target)
                        setattr(unit, stat, current_targets)
                continue
                
            # 处理继承关系和资源消耗
            if stat in ("is_a", "cost"):
                bonus_stat = f"{stat}_bonus"
                if hasattr(unit, bonus_stat):
                    bonus_value = getattr(unit, bonus_stat)
                    if stat == "cost":
                        current_cost = getattr(unit, stat, [0] * len(bonus_value))
                        new_cost = [c + b for c, b in zip(current_cost, bonus_value)]
                        setattr(unit, stat, new_cost)
                    continue
            
            # 处理伤害属性
            if stat in ("mdg", "rdg"):  # 只处理基础伤害属性
                bonus_stat = f"{stat}_bonus"
                if hasattr(unit, bonus_stat):
                    bonus_values = getattr(unit, bonus_stat)
                    base_value = getattr(unit, stat, 0)
                    
                    # 更新基础伤害值
                    if isinstance(bonus_values, (list, tuple)):
                        if 0 <= start_level < len(bonus_values):
                            bonus_value = bonus_values[start_level]
                            new_value = base_value + bonus_value
                            setattr(unit, stat, new_value)
                    else:
                        new_value = base_value + bonus_values
                        setattr(unit, stat, new_value)
                    
                    # 更新等级属性
                    level_stat = f"{stat}_level"
                    if not hasattr(unit, level_stat):
                        setattr(unit, level_stat, 0)
                    current_level = getattr(unit, level_stat)
                    setattr(unit, level_stat, current_level + 1)
                    print(f"DEBUG: {unit.type_name} {level_stat} upgraded from {current_level} to {current_level + 1}")
                    
                    # 更新vs属性
                    vs_stat = f"{stat}_vs"
                    if hasattr(unit, vs_stat):
                        vs_dict = getattr(unit, vs_stat)
                        for target_type in vs_dict:
                            vs_dict[target_type] += int(float(bonus_values[start_level] if isinstance(bonus_values, (list, tuple)) else bonus_values))
                continue
            
            # 处理其他伤害相关属性（如 mdg_vs, rdg_vs 等）
            if stat.startswith(("mdg_", "rdg_")) and stat not in ("mdg_level", "rdg_level"):
                bonus_stat = f"{stat}_bonus"
                if hasattr(unit, bonus_stat):
                    bonus_values = getattr(unit, bonus_stat)
                    base_value = getattr(unit, stat, 0)
                    
                    if isinstance(bonus_values, (list, tuple)):
                        if 0 <= start_level < len(bonus_values):
                            bonus_value = bonus_values[start_level]
                            new_value = base_value + bonus_value
                            setattr(unit, stat, new_value)
                    else:
                        new_value = base_value + bonus_values
                        setattr(unit, stat, new_value)
                continue
                
            # 处理普通bonus属性（支持多级升级）
            bonus_stat = stat + "_bonus"
            if hasattr(unit, bonus_stat):
                bonus_values = getattr(unit, bonus_stat)
                base_value = getattr(unit, stat, 0)
                
                # 如果是多级升级的bonus
                if isinstance(bonus_values, (list, tuple)):
                    # 确保start_level在有效范围内
                    if 0 <= start_level < len(bonus_values):
                        bonus_value = bonus_values[start_level]
                        new_value = base_value + bonus_value
                        setattr(unit, stat, new_value)
                else:
                    # 单级bonus，直接应用
                    new_value = base_value + bonus_values
                    setattr(unit, stat, new_value)