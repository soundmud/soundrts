import math
import random
import re
from typing import List, Optional, Set, Tuple

from .definitions import MAX_NB_OF_RESOURCE_TYPES, VIRTUAL_TIME_INTERVAL, rules
from .lib.log import warning
from .lib.nofloat import (
    PRECISION,
    int_angle,
    int_cos_1000,
    int_distance,
    int_sin_1000,
    square_of_distance,
    to_int,
)
from .worldaction import Action, AttackAction, MoveAction, MoveXYAction
from .worldentity import Entity
from .worldorders import (
    ORDERS_DICT,
    BuildPhaseTwoOrder,
    GoOrder,
    RallyingPointOrder,
    UpgradeToOrder,
    ProducingOrder,
)
from .worldresource import Corpse, Deposit
from .worldroom import Square, Inside, ZoomTarget

DISTANCE_MARGIN = 175  # millimeters


def ground_or_air(t):
    """返回 'ground' 或 'air'。如果 t == 'water'，则认为是 'ground'。"""
    return "ground" if t == "water" else t

def to_float(s) -> float:
    """
    将字符串 s 转为 float，如果异常则返回 0.0
    """
    try:
        return float(s)
    except (ValueError, TypeError):
        return 0.0


class Creature(Entity):

#新版字段
    hp_start_vs: dict = dict()
    hp_max_vs: dict = dict()
    hp_pool_vs: dict = dict()   # 多血槽存储

    # 旧伤害字段，先行注释掉
    # damage_vs: dict = dict()
   # 护甲（含 vs 修正）
#    armor_vs: dict = dict()

    # 新增的近战/远程伤害与修正
    mdg_vs: dict = dict()       # 近战伤害 vs 某些单位
    rdg_vs: dict = dict()       # 远程伤害 vs 某些单位
    mdf_vs: dict = dict()
    rdf_vs: dict = dict()
    # 冷却、前摇、射程、最小射程、命中/闪避等 vs 修正
    mdg_cd_vs: dict = dict()
    rdg_cd_vs: dict = dict()
    mdg_ready_vs: dict = dict()
    rdg_ready_vs: dict = dict()
    mdg_range_vs: dict = dict()
    rdg_range_vs: dict = dict()
    mdg_minimal_range_vs: dict = dict()
    rdg_minimal_range_vs: dict = dict()
    mdg_cover_vs: dict = dict()
    rdg_cover_vs: dict = dict()
    mdg_dodge_vs: dict = dict()
    rdg_dodge_vs: dict = dict()
    speed_vs: dict = dict()

    def _get_dodge_on_terrain(self, is_melee=True) -> int:
        """获取当前地形上的闪避修正（0~100）"""
        terrain_type = self.place.type_name if self.place else None
        if not terrain_type:
            return 0
            
        if is_melee and hasattr(self, 'mdg_dodge_on_terrain'):
            try:
                idx = self.mdg_dodge_on_terrain.index(terrain_type)
                if idx + 1 < len(self.mdg_dodge_on_terrain):
                    return int(self.mdg_dodge_on_terrain[idx + 1])
            except (ValueError, IndexError):
                pass
        elif not is_melee and hasattr(self, 'rdg_dodge_on_terrain'):
            try:
                idx = self.rdg_dodge_on_terrain.index(terrain_type)
                if idx + 1 < len(self.rdg_dodge_on_terrain):
                    return int(self.rdg_dodge_on_terrain[idx + 1])
            except (ValueError, IndexError):
                pass
        return 0

    def _get_height_bonus_range(self, is_melee=True):
        """计算基于高度和投射物类型的额外射程加成
        
        Args:
            is_melee: 是否为近战攻击
            
        Returns:
            int: 额外射程加成(内部单位:毫米)
        """
        if not hasattr(self, 'height') or not hasattr(self.place, 'high_ground'):
            return 0
            
        # 获取相应的投射物标志
        projectile_flag = self.mdg_projectile if is_melee else self.rdg_projectile
        if not projectile_flag:
            return 0
            
        # 计算与当前位置的高度差
        # 使用 high_ground 属性代替 ground_height
        height_diff = self.height - (self.place.height if hasattr(self.place, 'height') else 0)
        if height_diff <= 0:
            return 0
            
        # 每1级高度差增加4点射程
        return (height_diff // 1) * 4000  # 转换为内部单位(毫米)

    def _get_speed_vs(self, target):
        """获取单位对特定目标的移动速度"""
        # 如果没有指定目标，返回基础速度
        if target is None:
            return self.speed
        
    # 检查是否有针对这个目标类型的特定速度
        if hasattr(target, 'type_name') and target.type_name in self.speed_vs:
            return self.speed_vs[target.type_name]
        
    # 检查扩展类型
        if hasattr(target, 'expanded_is_a'):
            for t in target.expanded_is_a:
                if t in self.speed_vs:
                    return self.speed_vs[t]
                
    # 如果没有定义特定速度，返回默认速度
        return self.speed

    def _calc_relative_speed(self, target) -> int:
        """计算目标与攻击者的相对速度(使用内部单位)
        
        Returns:
            int: > 0 表示正在远离
                 < 0 表示正在接近
                 = 0 表示相对静止
        """
        # 如果目标没有移动行为，返回0
        if not isinstance(target.action, MoveAction):
            return 0
            
        # 获取双方位置
        ax, ay = self.x, self.y
        tx, ty = target.x, target.y
        
        # 获取目标的移动目的地
        dest = target.action.target
        if not dest or not hasattr(dest, 'x') or not hasattr(dest, 'y'):
            return 0
            
        # 计算目标移动向量
        move_x = dest.x - tx
        move_y = dest.y - ty
        
        # 计算目标相对攻击者的位移向量
        relative_x = tx - ax
        relative_y = ty - ay
        
        # 使用点积判断接近/远离
        dot_product = (move_x * relative_x + move_y * relative_y)
        dist2 = relative_x * relative_x + relative_y * relative_y
        
        if dist2 == 0:
            return 0
            
        # 获取目标实际速度
        actual_speed = target.actual_speed if hasattr(target, 'actual_speed') else target.speed
        
        # 返回相对速度(负值表示接近)
        return (dot_product * actual_speed) // int_distance(0, 0, relative_x, relative_y)

    def _schedule_ballistic_hit(self, target, damage_delay_ms: int, is_melee=False):
        """调度一次攻击序列"""
        # 获取投射物标记
        is_projectile = (is_melee and self.mdg_projectile) or (not is_melee and self.rdg_projectile)
        
        if is_projectile:
            # 计算相对速度并调整延迟
            relative_speed = self._calc_relative_speed(target)
            if relative_speed < 0:  # 目标正在接近
                # 计算距离
                distance = int_distance(self.x, self.y, target.x, target.y)
                # 计算预计相遇时间(考虑相对速度)
                meet_time = distance * 1000 // abs(relative_speed) if relative_speed != 0 else damage_delay_ms
                # 取较小值作为新延迟
                damage_delay_ms = min(damage_delay_ms, meet_time)
                
        # 限制最大和最小延迟
        damage_delay_ms = min(max(damage_delay_ms, 100), 5000)  # 100ms最小延迟,5000ms最大延迟
        
        # 原有的序列处理代码...
        if is_melee:
            times = min(self.mdg_seq_times, 6)
            damages = self.mdg_seq_damages
            interval = 0.4
        else:
            times = min(self.rdg_seq_times, 6) 
            damages = self.rdg_seq_damages
            interval = 0.4
        
        # 如果没有设置序列,使用单次攻击
        if not damages:
            damages = [self._get_melee_damage_vs(target) if is_melee 
                      else self._get_ranged_damage_vs(target)]
            times = 1
            interval = 0
            
        # 预计算所有伤害值和时间
        sequence = []
        base_delay = damage_delay_ms
        
        for i in range(times):
            damage = damages[i] if i < len(damages) else damages[-1]
            hit_time = self.world.time + base_delay + int(i * interval * 1000)
            sequence.append((hit_time, damage))
                
        # 按顺序创建攻击事件
        for hit_time, damage in sequence:
            def do_hit():
                if (target is None or target.player is None or target.hp <= 0 or
                    self.player is None or self.hp <= 0):
                    return
                    
                # 检查攻击范围,但在强制攻击时忽略
                if not getattr(self.action, 'is_imperative', False):
                    if is_melee and not self.in_melee_range(target):
                        return
                    elif not is_melee and not self.in_ranged_range(target):
                        return
                        
                # 命中判定和伤害处理
                if self._hit_or_miss(target):
                    target.receive_hit(damage, self)
                    target.apply_damage_over_time(is_melee=is_melee, base_damage=damage)
                    self.splash_aim(target, is_melee=is_melee)

            # 检查是否需要立即执行
            if (is_melee and self.mdg_delay == 0) or (not is_melee and self.rdg_delay == 0):
                do_hit()
            else:
                # 加入延迟调度
                self.world.schedule_after(hit_time - self.world.time, do_hit)
        
        # 处理冷却时间
        total_sequence_time = base_delay + int((times - 1) * interval * 1000)
        self.world.schedule_after(total_sequence_time, 
                                lambda: self._set_attack_cooldown(is_melee, target))

    def _set_attack_cooldown(self, is_melee, target=None):
        """设置攻击冷却时间
        
        Args:
            is_melee: 是否为近战攻击
            target: 攻击目标,可选
        """
        now = self.world.time
        if is_melee:
            cd = self._get_melee_cd_vs(target) if target else self.mdg_cd
            self.mdg_next_attack_time = now + min(cd, 5000)
        else:
            cd = self._get_ranged_cd_vs(target) if target else self.rdg_cd
            self.rdg_next_attack_time = now + min(cd, 5000)

    def aim(self, target):
        """瞄准目标并尝试攻击"""
        # 检查目标是否有效
        if target is None or target.player is None or target.hp <= 0:
            return

    # 检查是否可以从载具内攻击
        if not self._can_attack_from_inside():
        # 不发送攻击通知，直接返回
            return

        # 检查是否允许攻击载具内部目标
        if hasattr(target, 'is_inside') and target.is_inside and not self.allow_attack_inside:
            return

        # 获取当前时间
        now = self.world.time

        # 修改判断条件，只要有对应的伤害值就可以攻击
        can_mdg = (self.mdg > 0) and self.can_attack(target)
        can_rdg = (self.rdg > 0) and self.can_attack(target)

        # 优先尝试远程普通攻击
        if can_rdg:
            # 如果还在冷却，直接返回
            if now < self.rdg_next_attack_time:
                return
                
            # 检查前摇
            if self.rdg_prep_end_time <= 0:  # 如果没有前摇时间，设置新的前摇
                self.rdg_prep_end_time = now + self._get_range_ready_vs(target)
                return
            elif now < self.rdg_prep_end_time:  # 如果前摇未结束
                return
                
            # 前摇结束后发起攻击
            self.notify(f"launch_ratk,{self.type_name},{self.id}")
            damage_delay = self._calc_rdg_delay(target)
            self._schedule_ballistic_hit(target, damage_delay, is_melee=False)
            
            # 设置冷却时间并重置前摇时间
# 远程攻击部分
            self.rdg_next_attack_time = now + self._get_ranged_cd_vs(target)
            self.rdg_prep_end_time = 0
            
        # 近战攻击逻辑类似
        if can_mdg:
            if now < self.mdg_next_attack_time:
                return
                
            if self.mdg_prep_end_time <= 0:
                self.mdg_prep_end_time = now + self._get_melee_ready_vs(target)
                return
            elif now < self.mdg_prep_end_time:
                return
                
            self.notify(f"launch_matk,{self.type_name},{self.id}")
            damage_delay = self._calc_mdg_delay(target)
            self._schedule_ballistic_hit(target, damage_delay, is_melee=True)
            
            self.mdg_next_attack_time = now + self._get_melee_cd_vs(target)
            self.mdg_prep_end_time = 0

    def _calc_mdg_delay(self, target) -> int:
        dist_in_grids = int_distance(self.x, self.y, target.x, target.y) / 1000
        if dist_in_grids <= 0:
            return 0

    # 计算基础延迟
        base_delay = dist_in_grids * self.mdg_delay
        print(f"调试: 近战基础延迟: {base_delay}毫秒, 距离: {dist_in_grids}格")
    
        return int(round(base_delay))

    def _calc_rdg_delay(self, target) -> int:
    # 计算基础距离(转换为实际格子数)
        dist_in_grids = int_distance(self.x, self.y, target.x, target.y) / 1000
        if dist_in_grids <= 0:
            return 0

    # 计算基础延迟
        base_delay = dist_in_grids * self.rdg_delay
        print(f"调试: 远程基础延迟: {base_delay}毫秒, 距离: {dist_in_grids}格")
    
        return int(round(base_delay))


    def get_effective_mdg_range(self, target):
        """获取对特定目标的有效近战射程"""
        if not hasattr(self, 'mdg_range'):
            return 0
            
        # 如果射程为0，返回一个足够小的射程
        if self.mdg_range == 0:
            return 1
            
        # 获取基础射程
        base_range = self.mdg_range
        
        # 检查是否有针对特定目标的射程
        if hasattr(self, 'mdg_range_vs'):
            # 直接检查目标类型
            if target.type_name in self.mdg_range_vs:
                base_range = self.mdg_range_vs[target.type_name]
            # 检查目标的继承类型
            elif hasattr(target, 'expanded_is_a'):
                for t in target.expanded_is_a:
                    if t in self.mdg_range_vs:
                        base_range = self.mdg_range_vs[t]
                        break
        
        # 使用现有的高度加成方法
        height_bonus = self._get_height_bonus_range(is_melee=True)
        if height_bonus > 0:
            base_range += height_bonus
    
        return base_range

    def get_effective_rdg_range(self, target):
        """获取对特定目标的有效远程射程"""
        if not hasattr(self, 'rdg_range'):
            return 0
            
        # 如果射程为0，返回一个足够小的射程
        if self.rdg_range == 0:
            return 1
            
        # 获取基础射程
        base_range = self.rdg_range
        
        # 检查是否有针对特定目标的射程
        if hasattr(self, 'rdg_range_vs'):
            # 直接检查目标类型
            if target.type_name in self.rdg_range_vs:
                base_range = self.rdg_range_vs[target.type_name]
            # 检查目标的继承类型
            elif hasattr(target, 'expanded_is_a'):
                for t in target.expanded_is_a:
                    if t in self.rdg_range_vs:
                        base_range = self.rdg_range_vs[t]
                        break
        
        # 使用现有的高度加成方法
        height_bonus = self._get_height_bonus_range(is_melee=False)
        if height_bonus > 0:
            base_range += height_bonus
    
        return base_range


    # -------------- 射程判定：改用 mdg_range / rdg_range + minimal_range -------------- #
    def in_melee_range(self, target) -> bool:
        """判断目标是否在近战范围内"""
        dist2 = square_of_distance(self.x, self.y, target.x, target.y)
        effective_range = self.get_effective_mdg_range(target)  # 使用修正后的射程
        collision = self.radius + target.radius
        max_range2 = (effective_range + collision)**2

        # 获取针对目标的最小射程
        min_range = None
        if target.type_name in self.mdg_minimal_range_vs:
            min_range = self.mdg_minimal_range_vs[target.type_name]
        elif hasattr(target, 'expanded_is_a'):
            for t in target.expanded_is_a:
                if t in self.mdg_minimal_range_vs:
                    min_range = self.mdg_minimal_range_vs[t]
                    break
        if min_range is None:
            min_range = self.mdg_minimal_range
            
        if min_range > 0:
            min_range2 = (min_range + collision) ** 2
            if dist2 < min_range2:
                return False
        return dist2 <= max_range2

    def in_ranged_range(self, target) -> bool:
        """判断目标是否在远程范围内"""
        if self.rdg_range <= 0:
            return False
        dist2 = square_of_distance(self.x, self.y, target.x, target.y)
        effective_range = self.get_effective_rdg_range(target)  # 使用修正后的射程
        collision = self.radius + target.radius
        max_range2 = (effective_range + collision) ** 2

        # 获取针对目标的最小射程
        min_range = None
        if target.type_name in self.rdg_minimal_range_vs:
            min_range = self.rdg_minimal_range_vs[target.type_name]
        elif hasattr(target, 'expanded_is_a'):
            for t in target.expanded_is_a:
                if t in self.rdg_minimal_range_vs:
                    min_range = self.rdg_minimal_range_vs[t]
                    break
        if min_range is None:
            min_range = self.rdg_minimal_range
            
        if min_range > 0:
            min_range2 = (min_range + collision) ** 2
            if dist2 < min_range2:
                return False
        return dist2 <= max_range2

    def _get_melee_damage_vs(self, target) -> int:
        """返回对 target 的近战基础伤害（含 vs 修正）"""
        dmg_vs = self.mdg_vs.get(target.type_name, None)
        if dmg_vs is not None:
            return dmg_vs
        for t in target.expanded_is_a:
            if t in self.mdg_vs:
                return self.mdg_vs[t]
        return self.mdg

    def _get_ranged_damage_vs(self, target) -> int:
        """返回对 target 的远程基础伤害（含 vs 修正）"""
        dmg_vs = self.rdg_vs.get(target.type_name, None)
        if dmg_vs is not None:
            return dmg_vs
        for t in target.expanded_is_a:
            if t in self.rdg_vs:
                return self.rdg_vs[t]
        return self.rdg

    def _get_melee_defense_vs(self, attacker) -> int:
        """返回基于 mdf / mdf_vs 的近战防御值"""
        d = self.mdf_vs
        if attacker.type_name in d:
            return d[attacker.type_name]
        for t in attacker.expanded_is_a:
            if t in d:
                return d[t]
        return self.mdf

    def _get_ranged_defense_vs(self, attacker) -> int:
        """返回基于 rdf / rdf_vs 的远程防御值"""
        d = self.rdf_vs
        if attacker.type_name in d:
            return d[attacker.type_name]
        for t in attacker.expanded_is_a:
            if t in d:
                return d[t]
        return self.rdf


    @classmethod
    def interpret_vs_attributes(cls, d, attrs):
        """
        通用 vs 属性解析函数，例如将:
        ["footman", "2", "knight", "4", "archer", "3"]
        解析为 { "footman":2, "knight":4, "archer":3 }。
        """
        for attr in attrs:
            items = d.get(attr, [])
            d[attr] = dict()
            targets = []
            for s in items:
                try:
                    n = to_int(s)
                    for t in targets:
                        # 处理单位类型的单复数形式
                        d[attr][t] = n
                        
                        # 处理复数形式，兼容规则文件中使用了复数形式的情况
                        # 处理常见的复数形式规则
                        if t.endswith('s'):
                            # 简单复数形式: "soldiers" -> "soldier"
                            singular = t[:-1]
                            d[attr][singular] = n
                            
                            # 特殊复数规则: "cavalrys" -> "cavalry"
                            if t.endswith('ys'):
                                special_singular = t[:-2] + 'y'
                                d[attr][special_singular] = n
                        # 如果不是以s结尾，添加带s的形式
                        else:
                            # 常规单词: "soldier" -> "soldiers"
                            plural = t + 's'
                            d[attr][plural] = n
                            
                            # 处理特殊情况: "cavalry" -> "cavalrys"
                            if t.endswith('y'):
                                special_plural = t + 's'  # 有些游戏使用这种复数形式
                                d[attr][special_plural] = n
                    targets = []
                except ValueError:
                    targets.append(s)

    @classmethod
    def interpret(cls, d):
        """
        不再处理旧的 damage/damage_vs，仅解析新字段
        """
        vs_attributes = [
            #"armor_vs",
            "mdg_vs",
            "rdg_vs",
            "mdf_vs",
            "rdf_vs",
            "mdg_cd_vs",
            "rdg_cd_vs",
            "mdg_ready_vs",
            "rdg_ready_vs",
            "mdg_range_vs",
            "rdg_range_vs",
            "mdg_minimal_range_vs",
            "rdg_minimal_range_vs",
            "speed_vs",
            "hp_start_vs",
            "hp_max_vs",
            "hp_pool_vs",
            "mdg_cover_vs",
            "rdg_cover_vs",
            "mdg_dodge_vs",
            "rdg_dodge_vs",
        ]
        cls.interpret_vs_attributes(d, vs_attributes)


# 解析属性效果
#        cls.interpret_prop_effects(d, "mdg_prop")
#        cls.interpret_prop_effects(d, "rdg_prop")
#解析是否允许攻击内部目标
        if "allow_attack_inside" in d:
            cls.allow_attack_inside = int(d["allow_attack_inside"]) == 1

        # 解析夺取占领 - 只在明确定义时设置
        if "capture_hp_threshold" in d:
            cls.capture_hp_threshold = int(d["capture_hp_threshold"])
        else:
            cls.capture_hp_threshold = 0  # 默认不可夺取


    # 解析允   许攻击的单位类型
        if "allow_units_attack" in d:
            if "all" in d["allow_units_attack"]:
                cls.allow_units_attack = ["all"]
            else:
                cls.allow_units_attack = d["allow_units_attack"]
        else:
            cls.allow_units_attack = []

    # 解析属性加成
        if "allow_units_add" in d:
            cls.allow_units_add = {}
            items = d.get("allow_units_add", [])
            if not items:
                return
            
        # 如果是列表，每两个元素组成一对
            i = 0
            while i < len(items):
                if i + 1 >= len(items):
                    break
                try:
                    stat = str(items[i])
                    value = float(items[i + 1])
                    cls.allow_units_add[stat] = value
                    i += 2
                except (ValueError, IndexError):
                    i += 1

        # 解析近战溅射衰减
        if "mdg_splash_decay" in d:
            try:
                decay_str = d["mdg_splash_decay"]
                if "-" in decay_str:
                    min_val = float(decay_str.split("-")[0])
                    cls.mdg_splash_decay_min = min_val
                else:
                    cls.mdg_splash_decay_min = float(decay_str)
            except (ValueError, IndexError):
                warning(f"Invalid mdg_splash_decay format: {decay_str}")
                
        # 解析远程溅射衰减
        if "rdg_splash_decay" in d:
            try:
                decay_str = d["rdg_splash_decay"]
                if "-" in decay_str:
                    min_val = float(decay_str.split("-")[0])
                    cls.rdg_splash_decay_min = min_val
                else:
                    cls.rdg_splash_decay_min = float(decay_str)
            except (ValueError, IndexError):
                warning(f"Invalid rdg_splash_decay format: {decay_str}")


        # 解析 status_damage
        if "status_damage" in d:
            status_str = d["status_damage"]
            
            # 情况1: 统一设置两种伤害持续时间
            # 例如: "status_damage 2"
            if status_str.isdigit():
                duration = float(status_str)
                cls.mdg_status_duration = duration
                cls.rdg_status_duration = duration
                return
                
            # 情况2: 分别设置
            parts = status_str.split()
            i = 0
            while i < len(parts):
                if parts[i] == "melee_damage":
                    if i + 1 < len(parts) and parts[i+1].replace(".", "").isdigit():
                        cls.mdg_status_duration = float(parts[i+1])
                        i += 2
                    else:
                        i += 1
                elif parts[i] == "range_damage":
                    if i + 1 < len(parts) and parts[i+1].replace(".", "").isdigit():
                        cls.rdg_status_duration = float(parts[i+1])
                        i += 2
                    else:
                        i += 1
                else:
                    i += 1


        if "damage_seq" in d:
            seq_str = d["damage_seq"]
        
        # 解析攻击类型和次数
            match = re.search(r'(mdg|rdg)\s+(\d+)', seq_str)
            if match:
                damage_type = match.group(1)
                times = int(match.group(2))
            
            # 解析伤害序列
                damage_match = re.search(r'\(damage\s+([0-9\s]+)\)', seq_str)
                if damage_match:
                # 将伤害值转换为游戏内精度
                    damages = [int(x) * PRECISION for x in damage_match.group(1).split()]
                
                # 解析间隔时间
                    interval_match = re.search(r'\(interval\s+([\d\.]+)\)', seq_str)
                    interval = float(interval_match.group(1)) if interval_match else 0.0
                
                # 验证伤害总和是否等于基础伤害（使用相同精度）
                    base_damage = d.get(damage_type, 0) * PRECISION
                    if sum(damages) == base_damage:  # 现在比较的是相同精度的值
                    # 设置对应类型的攻击序列
                        if damage_type == "mdg":
                            cls.mdg_seq_times = times
                            cls.mdg_seq_damages = damages  # 存储精确值
                            cls.mdg_seq_interval = interval
                        else:
                            cls.rdg_seq_times = times
                            cls.rdg_seq_damages = damages  # 存储精确值
                            cls.rdg_seq_interval = interval

#解析近战目标
        mdg_targets_val = d.get("mdg_targets", "")
        if isinstance(mdg_targets_val, list):
            cls.mdg_targets = mdg_targets_val
        else:
            cls.mdg_targets = mdg_targets_val.replace(";","").strip().split() or ["ground"]

#解析远程目标
        rdg_targets_val = d.get("rdg_targets", "")
        if isinstance(rdg_targets_val, list):
            cls.rdg_targets = rdg_targets_val
        else:
            cls.rdg_targets = rdg_targets_val.replace(";","").strip().split() or ["ground"]


    type_name: Optional[str] = None
    is_a_unit = False
    is_a_building = False
    stat_type = None

    def get_action_target(self):
        if self.action:
            return self.action.target

    def set_action_target(self, value):
        if isinstance(value, tuple):
            self.action = MoveXYAction(self, value)
        elif isinstance(value, ZoomTarget):
            self.action = MoveXYAction(self, (value.x, value.y))
        elif self.is_an_enemy(value):
            self.action = AttackAction(self, value)
        elif value is not None:
            self.action = MoveAction(self, value)
        else:
            self.action = Action(self, value)

    action_target = property(get_action_target, set_action_target)
    distance_to_goal = float("inf")

    hp_start = 0
    hp_max = 0
    hp_regen = 0
    mana_max = 0
    mana_start = 0
    mana_regen = 0
    walked: List[Tuple[Optional[Square], int, int, int]] = []

    cost = (0,) * MAX_NB_OF_RESOURCE_TYPES
    time_cost = 0
    food_cost = 0
    food_provided = 0
    ai_mode: Optional[str] = None
    can_switch_ai_mode = False
    storable_resource_types = ()
    storage_bonus = ()

    is_buildable_anywhere = True

    inside = None
    transport_capacity = 0
    transport_volume = 1

    requirements = ()
    is_a = ()
    can_build = ()
    can_train = ()
    can_use = ()
    can_research = ()
    can_upgrade_to = ()

#    armor = 0
#    damage = 0
#    damage_level = 0
    mdg = 0  # 近战基础伤害
    rdg = 0  # 远程基础伤害
    mdf = 0  # 近战防御
    rdf = 0  # 远程防御
    mdg_level = 0
    rdg_level = 0
    mdg_minimal_damage = 0
    rdg_minimal_damage = 0

    basic_skills: Set[str] = set()

    is_vulnerable = True
    is_healable = True
    is_a_gate = False
    provides_survival = False


#    damage_radius = 0
#    target_types = ["ground"]
#    range = 0
#    is_ballistic = 0
#    minimal_range = 0
#    cooldown = 0
#    next_attack_time = 0
#    splash = False

    mdg_range = 0
    rdg_range = 0
    mdg_minimal_range = 0
    rdg_minimal_range = 0
    mdg_projectile = 0  # 近战攻击是否为投射物
    rdg_projectile = 0  # 远程攻击是否为投射物
    mdg_targets = ["ground"]
    rdg_targets = ["ground"]
    allow_units_attack = []     # 允许在载具内攻击的单位类型列表
    allow_units_add = {}        # 修改为字典类型的默认值
    _bonus_stats = {}           # 用于追踪各属性的总加成值
    allow_attack_inside = False  # 是否允许攻击载具内部单位
    capture_hp_threshold = 0  # 默认为0表示不可夺取
    _last_capture_time = 0  # 上次夺取尝试的时间
    _capture_cooldown = 10000  # 10秒冷却时间(毫秒)
    mdg_delay = 0 #近战伤害弹道
    rdg_delay = 0 #远程伤害弹道
    mdg_radius = 0
    rdg_radius = 0
    mdg_splash = 0
    rdg_splash = 0
    mdg_splash_decay_min = 0  # 近战默认最小衰减
    rdg_splash_decay_min = 0  # 远程默认最小衰减
    mdg_cd = 0
    rdg_cd = 0
    mdg_next_attack_time = 0
    rdg_next_attack_time = 0
    mdg_prep_end_time = 0
    rdg_prep_end_time = 0
    mdg_ready = 0
    rdg_ready = 0
    mdg_cover = 0
    rdg_cover = 0
    mdg_dodge = 0
    rdg_dodge = 0
    mdg_status_duration = 0      # 近战伤害持续时间
    rdg_status_duration = 0      # 远程伤害持续时间
    damage_seq = None
    mdg_seq_times: int = 1      # 近战攻击次数
    mdg_seq_damages: List[int] = []  # 近战伤害序列
    mdg_seq_interval: float = 0  # 近战攻击间隔
    
    rdg_seq_times: int = 1      # 远程攻击次数  
    rdg_seq_damages: List[int] = []  # 远程伤害序列
    rdg_seq_interval: float = 0  # 远程攻击间隔
    speed = 0

    player = None
    number = None

    expanded_is_a = ()

    rallying_point = None

    corpse = 1
    decay = 0

    presence = 1

    count_limit = 0
    group = None

    def _expand_is_a(self, is_a_list):
        """展开并记录所有继承关系"""
        if not is_a_list:
            return
            
        for base_type in is_a_list:
            if base_type not in self.expanded_is_a:
                self.expanded_is_a.add(base_type)
                # 递归处理基类的继承
                base_class = rules.get(base_type)
                if base_class and hasattr(base_class, 'is_a'):
                    self._expand_is_a(base_class.is_a)

    def next_free_number(self):
        numbers = [
            u.number
            for u in self.player.units
            if u.type_name == self.type_name and u is not self
        ]
        n = 1
        while n in numbers:
            n += 1
        return n

    def set_player(self, player):
        self.stop()
        self.cancel_all_orders(unpay=False)
        if self.player:
            self.player.remove(self)
        elif player:
            player.stats.add("produced", self.stat_type)
        self.player = player
        if player:
            player.add(self)
        if self.inside:
            for o in self.inside.objects:
                o.set_player(player)

    @classmethod
    def create_from_nowhere(cls):
        return cls.__new__(cls)

    def __init__(self, player, place, x, y, o=90):
        super().__init__(place, x, y, o)
        self.ai_mode = "offensive"  # 默认为进攻模式
        self.counterattack_enabled = False  # 默认关闭反击
        self.last_attacker = None  # 初始化最后攻击者
    # 1. 从类属性读取配置值（冷却时长、伤害等）
        self.mdg = type(self).mdg
        self.rdg = type(self).rdg
        self.mdf = type(self).mdf
        self.rdf = type(self).rdf
        self.mdg_range = type(self).mdg_range
        self.rdg_range = type(self).rdg_range
        self.mdg_minimal_range = type(self).mdg_minimal_range
        self.rdg_minimal_range = type(self).rdg_minimal_range
        self.mdg_radius = type(self).mdg_radius
        self.rdg_radius = type(self).rdg_radius
        self.mdg_splash = type(self).mdg_splash
        self.rdg_splash = type(self).rdg_splash
        self.mdg_delay = type(self).mdg_delay
        self.rdg_delay = type(self).rdg_delay
        self.mdg_cd = type(self).mdg_cd  # 冷却时长（毫秒）
        self.rdg_cd = type(self).rdg_cd
        self.mdg_ready = type(self).mdg_ready
        self.rdg_ready = type(self).rdg_ready
        self.mdg_status_duration = type(self).mdg_status_duration
        self.rdg_status_duration = type(self).rdg_status_duration
        self.mdg_cover = type(self).mdg_cover
        self.rdg_cover = type(self).rdg_cover
        self.mdg_dodge = type(self).mdg_dodge
        self.rdg_dodge = type(self).rdg_dodge
        
        # 复制vs属性
        self.mdg_vs = dict(type(self).mdg_vs)
        self.rdg_vs = dict(type(self).rdg_vs)
        self.mdf_vs = dict(type(self).mdf_vs)
        self.rdf_vs = dict(type(self).rdf_vs)
        self.mdg_cover_vs = dict(type(self).mdg_cover_vs)  # 确保复制vs属性
        self.rdg_cover_vs = dict(type(self).rdg_cover_vs)  # 确保复制vs属性
        self.mdg_dodge_vs = dict(type(self).mdg_dodge_vs)
        self.rdg_dodge_vs = dict(type(self).rdg_dodge_vs)
        
        # 初始化expanded_is_a集合
        if not hasattr(self, 'expanded_is_a') or not self.expanded_is_a:
            self.expanded_is_a = set()
            # 确保调用_expand_is_a来初始化expanded_is_a属性
            if hasattr(type(self), 'is_a'):
                self._expand_is_a(type(self).is_a)
        
    # 2. 初始化动态变化的实例属性（冷却计时器、前摇结束时间等）
        self.mdg_next_attack_time = 0
        self.rdg_next_attack_time = 0
        self.mdg_prep_end_time = 0
        self.rdg_prep_end_time = 0

    # 3. 其他实例属性初始化
        self._actual_speed = 0
        self.override_damage = None

        if self.transport_capacity:
            self.inside = Inside(self)

    # 确保坐标为整数
        x = int(float(x))  # 支持浮点数输入
        y = int(float(y))
        o = int(float(o))

    # 多血槽
        self.hp_pool_vs = {}

    # 将类属性复制到实例属性（深拷贝避免修改类属性）
        self.hp_max = getattr(self, 'hp_max', 0)  # 获取类属性或默认值
        self.hp_start = getattr(self, 'hp_start', 0)
        self.hp_max_vs = getattr(self, 'hp_max_vs', {}).copy()
        self.hp_start_vs = getattr(self, 'hp_start_vs', {}).copy()

    # 初始化生命值
        if hasattr(self, 'hp_start') and self.hp_start > 0:
            self.hp = self.hp_start
        else:
            self.hp = self.hp_max

    # 确保生命值是整数
        self.hp = int(self.hp)

        self.position_to_hold = place
        self.orders = []
        self.set_player(player)

    # 初始生命/魔法
        if self.hp_start > 0:
            self.hp = self.hp_start
        else:
            self.hp = self.hp_max
        if self.mana_start > 0:
            self.mana = self.mana_start
        else:
            self.mana = self.mana_max

    # 最小伤害
        self.minimal_damage = rules.get("parameters", "minimal_damage")
        if self.minimal_damage is None:
            self.minimal_damage = int(0.17 * PRECISION)

    # 处理生命衰减
        if self.decay:
            self.time_limit = self.world.time + self.decay
        # 添加持续伤害状态追踪
        self.mdg_dot_end_time = 0  # 近战持续伤害结束时间
        self.rdg_dot_end_time = 0  # 远程持续伤害结束时间
        self.mdg_dot_damage = 0    # 每次近战持续伤害量
        self.rdg_dot_damage = 0    # 每次远程持续伤害量


    def immediate_order_toggle_ai_mode(self):
        """切换 AI 模式的顺序：offensive -> defensive -> guard -> chase -> offensive"""
        modes = ["offensive", "defensive", "guard", "chase"]
        current_index = modes.index(self.ai_mode)
        next_index = (current_index + 1) % len(modes)
        self.ai_mode = modes[next_index]
        self.notify("order_ok")

    def immediate_order_toggle_counterattack(self):
        """处理反击开关命令"""
        # 切换反击状态
        self.counterattack_enabled = not self.counterattack_enabled
        
        # 发送状态变更通知
        if self.counterattack_enabled:
            self.notify("counterattack_enabled")
        else:
            self.notify("counterattack_disabled")
            
        # 发送命令完成通知
        self.notify("order_ok")

    def counterattack(self, place):
        """在反击开启时才执行反击"""
        # 检查反击开关状态
        if not hasattr(self, 'counterattack_enabled') or not self.counterattack_enabled:
            return
            
        # 整合旧版本的所有条件检查
        if not (self.speed
            and self.menace
            and self.ai_mode == "offensive"
            and not self.orders
            and self.action.__class__ != AttackAction
            and self._can_go(place)):  # 使用 _can_go 而不是 can_go
            return
            
        # 执行反击移动
        self.take_order(["go", place.id])
        self.take_order(
            ["go", f"zoom-{self.place.id}-{self.x}-{self.y}"],
            forget_previous=False
        )


    def apply_damage_over_time(self, is_melee: bool, base_damage: int):
        """应用持续伤害效果"""
        now = self.world.time
        
        if is_melee and self.mdg_status_duration > 0:
            self.mdg_dot_end_time = now + int(self.mdg_status_duration * 1000)  # 转换为毫秒
            self.mdg_dot_damage = base_damage // 4  # 可以调整持续伤害比例
            
        elif not is_melee and self.rdg_status_duration > 0:
            self.rdg_dot_end_time = now + int(self.rdg_status_duration * 1000)
            self.rdg_dot_damage = base_damage // 4
            
    def update(self):
        """更新单位状态"""
        # 确保坐标为整数
        self.x = int(self.x)
        self.y = int(self.y)

        """在每帧更新时检查并应用持续伤害"""
        super().update()  # 确保调用父类的update
        
        now = self.world.time
        
        # 检查近战持续伤害
        if now < self.mdg_dot_end_time and self.mdg_dot_damage > 0:
            self.receive_hit(self.mdg_dot_damage, None, notify=False)
            
        # 检查远程持续伤害    
        if now < self.rdg_dot_end_time and self.rdg_dot_damage > 0:
            self.receive_hit(self.rdg_dot_damage, None, notify=False)

    def get_effective_melee_damage(self, target):
        """获取普通物理伤害，优先使用vs系统，没有则使用基础伤害"""
        if hasattr(self, 'mdg_vs'):
            # 先检查具体单位类型
            if target.type_name in self.mdg_vs:
                return self.mdg_vs[target.type_name]
            # 再检查单位的继承类型
            for t in target.expanded_is_a:
                if t in self.mdg_vs:
                    return self.mdg_vs[t]
        return getattr(self, 'mdg', 0)

    def get_effective_range_damage(self, target):
        """获取普通魔法伤害，优先使用vs系统，没有则使用基础伤害"""
        if hasattr(self, 'rdg_vs'):
            # 先检查具体单位类型
            if target.type_name in self.rdg_vs:
                return self.rdg_vs[target.type_name]
            # 再检查单位的继承类型
            for t in target.expanded_is_a:
                if t in self.rdg_vs:
                    return self.rdg_vs[t]
        return getattr(self, 'rdg', 0)


    def _get_total_melee_defense_vs(self, attacker) -> int:
        """获取总的近战防御值"""
        return self._get_melee_defense_vs(attacker)  # 直接返回基础mdf

    def _get_total_ranged_defense_vs(self, attacker) -> int:
        """获取总的远程防御值"""
        return self._get_ranged_defense_vs(attacker)  # 直接返回基础rdf


    def _get_melee_cover_vs(self, target) -> int:
        """返回对目标的近战命中修正（0~100）"""
        # 若 self.mdg_cover_vs 中包含对目标的特殊修正
        if target.type_name in self.mdg_cover_vs:
            return self.mdg_cover_vs[target.type_name] // 1000  # vs值需要除以1000还原为0~100
        
        # 检查扩展类型
        if hasattr(target, 'expanded_is_a'):
            for t in target.expanded_is_a:
                if t in self.mdg_cover_vs:
                    return self.mdg_cover_vs[t] // 1000  # vs值需要除以1000还原为0~100
                    
        # 默认值需要除以1000还原
        return self.mdg_cover // 1000 if self.mdg_cover else 100  # 默认100%命中

    def _get_ranged_cover_vs(self, target) -> int:
        """返回对目标的远程命中修正（0~100）"""
        if target.type_name in self.rdg_cover_vs:
            val = self.rdg_cover_vs[target.type_name] // 1000  # vs值需要除以1000还原为0~100
            return val
        
        # 检查扩展类型
        if hasattr(target, 'expanded_is_a'):
            for t in target.expanded_is_a:
                if t in self.rdg_cover_vs:
                    return self.rdg_cover_vs[t] // 1000  # vs值需要除以1000还原为0~100
        
        # 如果没有特定修正，使用基础命中率
        # 注意：这里需要除以1000来还原实际命中率
        val = self.rdg_cover // 1000 if self.rdg_cover else 100
        return val

    def _get_dodge_vs(self, attacker, is_melee=True) -> int:
        """
        当对方来攻击我时，我的闪避率是多少？(0~100)
        """
        if is_melee:
            # 检查是否有针对特定攻击者的闪避修正
            if hasattr(self, 'mdg_dodge_vs') and hasattr(attacker, 'type_name') and attacker.type_name in self.mdg_dodge_vs:
                dodge_value = self.mdg_dodge_vs[attacker.type_name]
                # 如果值大于100，假定它是内部值(需要除以1000)
                if dodge_value > 100:
                    dodge_value = dodge_value // 1000
                return dodge_value
            
            # 检查扩展类型
            if hasattr(self, 'mdg_dodge_vs') and hasattr(attacker, 'expanded_is_a'):
                for t in attacker.expanded_is_a:
                    if t in self.mdg_dodge_vs:
                        dodge_value = self.mdg_dodge_vs[t]
                        # 如果值大于100，假定它是内部值(需要除以1000)
                        if dodge_value > 100:
                            dodge_value = dodge_value // 1000
                        return dodge_value
            
            # 默认值需要除以1000还原
            base_dodge = self.mdg_dodge // 1000 if hasattr(self, 'mdg_dodge') and self.mdg_dodge else 0
            return base_dodge
        else:
            # 检查是否有针对特定攻击者的闪避修正
            if hasattr(self, 'rdg_dodge_vs') and hasattr(attacker, 'type_name') and attacker.type_name in self.rdg_dodge_vs:
                dodge_value = self.rdg_dodge_vs[attacker.type_name]
                # 如果值大于100，假定它是内部值(需要除以1000)
                if dodge_value > 100:
                    dodge_value = dodge_value // 1000
                return dodge_value
            
            # 检查扩展类型
            if hasattr(self, 'rdg_dodge_vs') and hasattr(attacker, 'expanded_is_a'):
                for t in attacker.expanded_is_a:
                    if t in self.rdg_dodge_vs:
                        dodge_value = self.rdg_dodge_vs[t]
                        # 如果值大于100，假定它是内部值(需要除以1000)
                        if dodge_value > 100:
                            dodge_value = dodge_value // 1000
                        return dodge_value
            
            # 默认值需要除以1000还原
            base_dodge = self.rdg_dodge // 1000 if hasattr(self, 'rdg_dodge') and self.rdg_dodge else 0
            return base_dodge


    def get_effective_hp_max(self, target=None):
        """根据 target 的类型，返回对其有效的 hp_max。"""
        if target:
            for t in target.expanded_is_a:
                if t in self.hp_max_vs:
                    return self.hp_max_vs[t]
            if target.type_name in self.hp_max_vs:
                return self.hp_max_vs[target.type_name]
        return self.hp_max

    def get_effective_hp_start(self, target=None):
        """根据 target 的类型，返回对其有效的 hp_start。"""
        if target:
            for t in target.expanded_is_a:
                if t in self.hp_start_vs:
                    return self.hp_start_vs[t]
            if target.type_name in self.hp_start_vs:
                return self.hp_start_vs[target.type_name]
        return self.hp_start or self.hp_max

    def move_to(self, place, x, y, o=90):
        """重写 Entity.move_to 方法以添加速度修正和地形效果
        
        Args:
            place: 目标区域
            x: 目标x坐标
            y: 目标y坐标
            o: 朝向角度(默认90度)
        """
        # 调用父类的 move_to 进行基础移动
        # 调用父类的 move_to 进行基础移动
        super().move_to(place, x, y, o)
        
        # 应用速度修正
        target = getattr(self, 'action_target', None)
        if target is not None:
            self._actual_speed = self._get_speed_vs(target)
        else:
            self._actual_speed = getattr(self, 'speed', 0)
            
        # 应用地形速度修正 - 添加防御性检查
        if (hasattr(self, 'speed_on_terrain') and place and 
            not isinstance(place, Inside) and  # 添加对Inside类的检查
            hasattr(place, 'type_name') and place.type_name and 
            place.type_name in self.speed_on_terrain):
            try:
                terrain_index = self.speed_on_terrain.index(place.type_name) + 1
                if terrain_index < len(self.speed_on_terrain):
                    self._actual_speed = int(self.speed_on_terrain[terrain_index])
            except (ValueError, IndexError):
                # 如果地形类型不在列表中或索引越界，使用默认地形速度修正
                if hasattr(place, 'terrain_speed'):
                    terrain_type = 0 if getattr(self, 'airground_type', None) == "ground" else 1
                    if terrain_type < len(place.terrain_speed):
                        self._actual_speed = (self._actual_speed * place.terrain_speed[terrain_type]) // 100
        
        # 确保最小速度
        if self._actual_speed > 0:
            self._actual_speed = max(self._actual_speed, getattr(self, 'VERY_SLOW', 1))

    def _get_melee_cd_vs(self, target) -> int:
        """返回对于某些单位的近战冷却时间
        
        Args:
            target: 目标单位
            
        Returns:
            int: 冷却时间
        """
        # 先看看 mdg_cd_vs 里有没有针对 target.type_name
        cd_vs = self.mdg_cd_vs.get(target.type_name, None)
        if cd_vs is not None:
            return cd_vs
            
        # 或者看看 target.expanded_is_a
        for t in target.expanded_is_a:
            if t in self.mdg_cd_vs:
                return self.mdg_cd_vs[t]
                
        # 否则用 mdg_cd
        return self.mdg_cd

    def _get_ranged_cd_vs(self, target) -> int:
        cd_vs = self.rdg_cd_vs.get(target.type_name, None)
        if cd_vs is not None:
            return cd_vs
        for t in target.expanded_is_a:
            if t in self.rdg_cd_vs:
                return self.rdg_cd_vs[t]
        return self.rdg_cd

    def _get_melee_ready_vs(self, target) -> int:
        """
        返回对目标的近战前摇（攻击预备时间）
        """
        ready_vs = self.mdg_ready_vs.get(target.type_name, None)
        if ready_vs is not None:
            return ready_vs
        for t in target.expanded_is_a:
            if t in self.mdg_ready_vs:
                return self.mdg_ready_vs[t]
        return self.mdg_ready

    def _get_range_ready_vs(self, target) -> int:
        """
        返回对目标的远程前摇（攻击预备时间）
        """
        ready_vs = self.rdg_ready_vs.get(target.type_name, None)
        if ready_vs is not None:
            return ready_vs
        for t in target.expanded_is_a:
            if t in self.rdg_ready_vs:
                return self.rdg_ready_vs[t]
        return self.rdg_ready


    def engage_combat(self, target):
#        print("DEBUG: engage_combat() called, target =", target)
        # 示例：可在此处做对战时的额外处理
        pass

    @property
    def current_speed(self) -> int:
        """只读，始终根据状态动态返回"当前真实移动速度"""
        if isinstance(self.action, AttackAction) and self.action.target:
            return self._get_speed_vs(self.action.target)
        else:
            return self._actual_speed


    def upgrade_to_player_level(self):
        for upg in self.can_use:
            if upg in self.player.upgrades:
                rules.unit_class(upg).upgrade_unit_to_player_level(self)

    @property
    def actual_speed(self):
        return self._actual_speed

    @actual_speed.setter
    def actual_speed(self, val):
        self._actual_speed = val

    @property
    def current_speed(self) -> int:
        """只读，始终根据状态动态返回"当前真实移动速度"""
        if isinstance(self.action, AttackAction) and self.action.target:
            return self._get_speed_vs(self.action.target)
        else:
            return self._actual_speed

    @property
    def is_melee(self) -> bool:
        """
        若我们认定 "近战" 表示: 具有mdg_range>0 并且没有rdg_range(或rdg_range=0)
        """
        return (self.mdg_range > 0) and (self.rdg_range <= 0)

    def upgrade_to_player_level(self):
        for upg in self.can_use:
            if upg in self.player.upgrades:
                rules.unit_class(upg).upgrade_unit_to_player_level(self)

    @property
    def upgrades(self):
        return [u for u in self.can_use if u in self.player.upgrades]

    # method required by transports and shelters (inside)
    def contains_enemy(self, player):
        return False

    @property
    def height(self):
        if self.airground_type == "air":
            return 2
        else:
            return self.place.height + self.bonus_height

    def nearest_water(self):
        places = [sq for sq in self.place.strict_neighbors if sq.is_water]
        if places:
            return min(
                places, key=lambda sq: square_of_distance(sq.x, sq.y, self.x, self.y)
            )

    def get_observed_squares(self, strict=False):
        if self.is_inside or self.place is None:
            return []
        result = [self.place]
        if strict and self.sight_range < self.world.square_width:
            return result
        for sq in self.place.neighbors:
            if (
                self.height > sq.height
                or self.height == sq.height
                and (
                    self._can_go(sq, ignore_forests=True)
                    or sq.is_water
                    or self.place.is_water
                )
            ):
                result.append(sq)
        return result


    @property
    def menace(self):
        """Calculate unit's menace value
        
        Returns:
            int: Menace value based on:
            1. If unit has melee or ranged damage, menace equals the higher value
            2. If unit has transport capacity, menace equals transport_capacity * PRECISION * 2
            3. If none of above, menace equals 0
        """
        damage = max(getattr(self, 'mdg', 0), getattr(self, 'rdg', 0))
        
        if damage:
            return damage
        if getattr(self, 'transport_capacity', 0):
            return self.transport_capacity * PRECISION * 2
        return 0

    @property
    def activity(self):
        try:
            o = self.orders[0]
        except IndexError:
            return
        if hasattr(o, "mode") and o.mode == "build":
            return "building"
        if hasattr(o, "mode") and o.mode == "gather" and hasattr(o.target, "type_name"):
            return "exploiting_%s" % o.target.type_name

    # reach (avoiding collisions)

    def _already_walked(self, x, y):
        n = 0
        radius_2 = self.radius * self.radius
        for lw, xw, yw, weight in self.walked:
            if self.place is lw and square_of_distance(x, y, xw, yw) < radius_2:
                n += weight
        return n

    def _future_coords(self, rotation, target_d):
        d = self.actual_speed * VIRTUAL_TIME_INTERVAL // 1000
        if rotation == 0:
            d = min(d, target_d)  # stop before colliding target
        a = self.o + rotation
        x = int(self.x + d * int_cos_1000(a) // 1000)
        y = int(self.y + d * int_sin_1000(a) // 1000)
        return x, y

    def _heuristic_value(self, rotation, target_d):
        x, y = self._future_coords(rotation, target_d)
        return abs(rotation) + self._already_walked(x, y) * 200

    def _can_go(self, new_place, ignore_blockers=False, ignore_forests=False):
        if new_place is None:
            return False  # out of the map
        if self.airground_type != "ground":
            return True
        if new_place is self.place:
            return True
        for e in self.place.exits:
            if e.other_side.place is new_place:
                if ignore_blockers:
                    return True
                if e.is_blocked(self, ignore_forests=ignore_forests):
                    for o in e.blockers:
                        self.player.observe(o)
                else:
                    return True
            else:
                for e2 in e.other_side.place.exits:
                    if e2.other_side.place is new_place:
                        if ignore_blockers or not e2.is_blocked(
                            self, ignore_forests=ignore_forests
                        ):
                            return True

    def _mark_the_dead_end(self) -> None:
        self.walked.append((self.place, self.x, self.y, 5))

    def _must_hold(self):
        return (
            not (self.player.smart_units or self.ai_mode == "defensive")
            and self.position_to_hold is not None
            and self.position_to_hold.contains(self.x, self.y)
        )

    def _must_not_go_to(self, x, y):
        return self._must_hold() and not self.position_to_hold.contains(x, y)

    def _try(self, rotation, target_d):
        x, y = self._future_coords(rotation, target_d)
        new_place = self.world.get_place_from_xy(x, y)
        if self._must_not_go_to(x, y):
            return False
        if self._can_go(new_place) and not self.would_collide_if(x, y):
            if abs(rotation) >= 90:
                self._mark_the_dead_end()
            self.move_to(new_place, x, y, self.o + rotation)
            self.unblock()
            return True

    _rotations = None
    _smooth_rotations = None

    def _reach(self, target_d):
        if self._smooth_rotations:  # "smooth rotation" mode
            rotation = self._smooth_rotations.pop(0)
            if self._try(rotation, target_d) or self._try(-rotation, target_d):
                self._smooth_rotations = []
        else:
            if not self._rotations:
                # update memory of dead ends
                self.walked = [x[0:3] + (x[3] - 1,) for x in self.walked if x[3] > 1]
                # "go straight" mode
                if not self.walked and self._try(0, target_d):
                    return
                # enter "rotation mode"
                self._rotations = [
                    (self._heuristic_value(x, target_d), x)
                    for x in (0, 45, -45, 90, -90, 135, -135, 180)
                ]
                self._rotations.sort()
            # "rotation" mode
            for _ in range(min(4, len(self._rotations))):
                _, rotation = self._rotations.pop(0)
                if self._try(rotation, target_d):
                    self._rotations = []
                    return
            if not self._rotations:
                # enter "smooth rotation mode"
                self._smooth_rotations = list(range(1, 180, 1))
                self.walked = []
                self._mark_the_dead_end()
                self.notify("collision")

    # hold

    def deploy(self):
        if isinstance(self.position_to_hold, ZoomTarget):
            self.action_target = self.position_to_hold
        elif self.player.smart_units:
            self.action_target = self.player.get_safest_subsquare(self.place)
        else:
            self.action_target = self.place.x, self.place.y

    def is_in_position(self, target):
        if self.place is target:
            return True
        if isinstance(target, ZoomTarget):
            return target.contains(self.x, self.y)

    def hold(self, target):
        self.position_to_hold = target
        self.deploy()

    # reach

    @property
    def is_melee(self) -> bool:
        """
        若我们认定 "近战" 表示: 具有mdg_range>0 并且没有rdg_range(或rdg_range=0)
        """
        return (self.mdg_range > 0) and (self.rdg_range <= 0)

    def _near_enough_to_aim(self, target):
        dist2 = square_of_distance(self.x, self.y, target.x, target.y)
        collision = self.radius + getattr(target, 'radius', 0)
        DEFAULT_ATTACK_RANGE = 175

        can_use_mdg = False
        if self.mdg > 0:
            max_range = self.get_effective_mdg_range(target) if self.get_effective_mdg_range(target) > 0 else DEFAULT_ATTACK_RANGE
            max_r2 = (max_range + collision) ** 2
            
            # 获取针对目标的最小射程
            min_range = None
            if target.type_name in self.mdg_minimal_range_vs:
                min_range = self.mdg_minimal_range_vs[target.type_name]
            elif hasattr(target, 'expanded_is_a'):
                for t in target.expanded_is_a:
                    if t in self.mdg_minimal_range_vs:
                        min_range = self.mdg_minimal_range_vs[t]
                        break
            if min_range is None:
                min_range = self.mdg_minimal_range
                
            if min_range > 0:
                min_r2 = (min_range + collision) ** 2
                if min_r2 <= dist2 <= max_r2:
                    can_use_mdg = True
            else:
                if dist2 <= max_r2:
                    can_use_mdg = True

        can_use_rdg = False
        if self.rdg > 0:
            max_range = self.get_effective_rdg_range(target) if self.get_effective_rdg_range(target) > 0 else DEFAULT_ATTACK_RANGE
            max_r2 = (max_range + collision) ** 2
            
            # 获取针对目标的最小射程
            min_range = None
            if target.type_name in self.rdg_minimal_range_vs:
                min_range = self.rdg_minimal_range_vs[target.type_name]
            elif hasattr(target, 'expanded_is_a'):
                for t in target.expanded_is_a:
                    if t in self.rdg_minimal_range_vs:
                        min_range = self.rdg_minimal_range_vs[t]
                        break
            if min_range is None:
                min_range = self.rdg_minimal_range
                
            if min_range > 0:
                min_r2 = (min_range + collision) ** 2
                if min_r2 <= dist2 <= max_r2:
                    can_use_rdg = True
            else:
                if dist2 <= max_r2:
                    can_use_rdg = True

        return can_use_mdg or can_use_rdg

    def _near_enough(self, target):
        # note: always returns False if the target is a square
        if target.place is self.place:
            d = self.radius + target.radius + DISTANCE_MARGIN
            return square_of_distance(self.x, self.y, target.x, target.y) < d * d

    def _collision_range(self, other):
        if (
            self.collision
            and other.collision
            and other.airground_type == self.airground_type
        ):
            return self.radius + other.radius
        else:
            return 0

    def action_reach_and_stop(self):
        target = self.action_target
        if not self._near_enough(target):
            d = int_distance(self.x, self.y, target.x, target.y)
            self.o = int_angle(
                self.x, self.y, target.x, target.y
            )  # turn toward the goal
            self._reach(d - self._collision_range(target))
        else:
            self.walked = []
            self.target = None

    def action_reach_and_aim(self):
        target = self.action_target
        if not target:
            # 如果没有目标就直接返回，以免后面 target.x, target.y 报错
            return

        # 原本逻辑：还没有到可以攻击/瞄准的距离，继续移动
        if not self._near_enough_to_aim(target):
            d = int_distance(self.x, self.y, target.x, target.y)
            self.o = int_angle(self.x, self.y, target.x, target.y)  # turn toward the goal
            self._reach(d - self._collision_range(target))
        else:
            self.walked = []
            self.aim(target)

    def go_to_xy(self, x, y):
        d = int_distance(self.x, self.y, x, y)
        if d > self.radius:
            self.o = int_angle(self.x, self.y, x, y)  # turn toward the goal
            self._reach(d)
        else:
            return True

    # update

    def has_imperative_orders(self):
        return self.orders and self.orders[0].is_imperative

    def _execute_orders(self):
        queue = self.orders
        if queue[0].is_complete or queue[0].is_impossible:
            queue.pop(0)
        else:
            queue[0].update()

    def _is_attacking(self):
        return isinstance(self.action, AttackAction)

    def update(self):
        # 确保基础属性都是整数类型
        self.x = int(self.x)
        self.y = int(self.y)
        self.o = int(self.o)
        
        assert isinstance(self.x, int)
        assert isinstance(self.y, int)
        assert isinstance(self.o, int)
        
        self.is_moving = False
        
        if self.player is None:
            return

        if self.heal_level:
            self.heal_nearby_units()
        if self.harm_level:
            self.harm_nearby_units()
        if self.inside:
            self.inside.update()

        if self.player is None:
            return

        if self.action:
            self.action.update()

        if self.player is None:
            return

        if self.has_imperative_orders():
            # warning: completing UpgradeToOrder deletes the object
            self._execute_orders()
        else:
            self.decide()
            if not self._is_attacking() and self.orders:
                self._execute_orders()

    # slow update

    def regenerate(self):
        if self.hp_regen and self.hp < self.hp_max:
            self.hp = min(self.hp_max, self.hp + self.hp_regen)
        if self.mana_regen and self.mana < self.mana_max:
            self.mana = min(self.mana_max, self.mana + self.mana_regen)

    def slow_update(self):
        self.regenerate()
        # 如果单位正在生产资源，处理生产逻辑
        if getattr(self, "is_producing", False):
            self.update_production()
        if self.time_limit is not None and self.place.world.time >= self.time_limit:
            self.on_disappear()  # 使用on_disappear而不是die，以便正确播放disappear音效

    def debug_log(self, message):
        """输出调试日志到文件"""
        if not hasattr(self, "player") or not self.player or not hasattr(self.player, "is_human") or not self.player.is_human:
            return
            
        try:
            import os
            import datetime
            log_dir = os.path.join(os.path.dirname(__file__), "logs")
            if not os.path.exists(log_dir):
                os.makedirs(log_dir)
                
            log_file = os.path.join(log_dir, "production_debug.log")
            with open(log_file, "a", encoding="utf-8") as f:
                timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                f.write(f"[{timestamp}] {message}\n")
        except Exception as e:
            print(f"日志记录失败: {e}")

    def update_production(self):
        """更新资源生产进度"""
        if not hasattr(self, "is_producing") or not self.is_producing:
            self.debug_log(f"单位 {self.type_name}({self.id}) 不在生产状态")
            return
            
        # 确保生产时间不为零
        if getattr(self, "production_time", 0) <= 0:
            self.debug_log(f"生产时间为零或不存在，无法生产: {self.production_time}")
            return
        
        # 计算每秒应增加的进度量（因为slow_update每秒调用一次）
        # 例如：如果production_time=300秒，那么每秒增加的进度应为1
        progress_per_second = 1  # 每秒增加1点进度
        
        # 增加生产进度
        old_progress = self.production_progress
        # self.production_progress += VIRTUAL_TIME_INTERVAL  # 原来的代码
        self.production_progress += progress_per_second  # 每秒增加1点进度
        
        # 添加调试日志，帮助追踪生产进度
        progress_percent = int(self.production_progress * 100 / self.production_time)
        self.debug_log(f"资源生产进度: {progress_percent}%, 当前进度: {self.production_progress}/{self.production_time}, 增加: {progress_per_second}")
        
        # 添加进度条通知，使用与ProductionOrder类相同的机制
        self._notify_production_completeness()
        
        # 当进度达到生产时间时，完成生产
        if self.production_progress >= self.production_time:
            self.debug_log(f"生产进度已达到目标，准备完成生产")
            self.complete_production()
    
    def _notify_production_completeness(self):
        """通知生产进度，与ProductionOrder._notify_completeness逻辑一致"""
        # 确保production_time不为0
        if getattr(self, "production_time", 0) == 0:
            return
            
        # 计算完成度（0-10的整数）
        c = int(self.production_progress * 10 / self.production_time)
        if c > 10:  # 确保不超过10
            c = 10
            
        # 检查是否有_previous_completeness属性，如果没有则初始化
        if not hasattr(self, "_previous_completeness"):
            self._previous_completeness = None
            
        # 只有当完成度发生变化时才发送通知
        if c != self._previous_completeness:
            self.debug_log(f"发送进度条通知: completeness,{c}")
            self.notify("completeness,%s" % c)
            self._previous_completeness = c
            
    def complete_production(self):
        """完成资源生产"""
        if not self.player:
            self.debug_log("无法完成生产: 单位没有所属玩家")
            return
            
        # 获取生产的资源类型和数量
        resource_type = getattr(self, "production_type", "resource1")
        production_qty = getattr(self, "production_qty", 0)
        
        # 将产量乘以1000
        production_qty *= 1000
        
        # 输出调试信息
        self.debug_log(f"完成资源生产，类型：{resource_type}，数量：{production_qty}")
        
        # 将资源添加到玩家的资源池
        if production_qty > 0:
            # 记录添加前的资源量
            before_resources = self.player.resources[:]
            
            # 添加资源
            self.player.store(resource_type, production_qty)
            
            # 记录添加后的资源量
            after_resources = self.player.resources[:]
            
            # 记录日志
            self.debug_log(f"资源变化: {before_resources} -> {after_resources}")
            
            # 发送通知（但不包括complete，避免触发"gold_house1 完成"的提示）
            self.notify("produced_%s,%s" % (resource_type.replace("resource", ""), production_qty))
            
            # 直接播放资源生产完成声音，但不触发完成提示
            # 将这个事件定义为"resource_complete"而不是"complete"来区分
            for player in self.player.world.players:
                if player is self.player:
                    # 注册事件处理器
                    player.send_event(self, "resource_complete")
            
        # 检查玩家是否有足够资源开始新的生产周期
        production_cost = getattr(self, "production_cost", (0, 0))
        result = self.check_if_enough_resources(production_cost, 0)
        
        # 从worldorders模块导入ProducingOrder
        from soundrts.worldorders import ProducingOrder
        
        if result is None:  # 如果有足够的资源
            # 支付新的生产成本
            self.player.pay(production_cost)
            
            # 重置生产进度并保持生产状态
            self.production_progress = 0
            self._previous_completeness = None  # 重置进度条通知的上一次完成度
            self.debug_log("资源足够，自动开始新的生产周期")
            
            # 确保orders中有一个ProducingOrder
            has_producing_order = False
            for order in self.orders:
                if isinstance(order, ProducingOrder):
                    has_producing_order = True
                    break
                    
            if not has_producing_order:
                # 添加新的ProducingOrder
                producing_order = ProducingOrder(self, [])
                self.orders.insert(0, producing_order)
            
            # 发送通知
            self.notify("order_ok")
        else:
            # 如果资源不足，停止生产
            self.is_producing = False
            self.production_progress = 0
            self._previous_completeness = None
            self.debug_log(f"资源不足，停止生产循环: {result}")
            
            # 从命令队列中移除ProducingOrder
            for i, order in enumerate(self.orders[:]):
                if isinstance(order, ProducingOrder):
                    self.orders.pop(i)
                    break
            
            # 发送资源不足通知
            self.notify(result)

    #

    def _raise_subsquare_threat(self, delta):
        subsquare = self.world.get_subsquare_id_from_xy(self.x, self.y)
        for p in self.player.allied_vision:
            if p in self.player.allied:
                p.raise_threat(subsquare, delta)

    def receive_hit(self, damage, attacker, notify=True):
        # 防御性检查
        if self.player is None or self.hp <= 0:
            return
            
        # 记录攻击者并通知玩家
        if attacker is not None:
            self.player.observe(attacker)
            self.last_attacker = attacker
            
            # 通知友军单位（仅当攻击者存在时）
            if self.place:
                self._notify_guard_units(attacker)

        # 计算实际伤害
        actual_damage = self._calculate_actual_damage(damage, attacker)
        
        # 应用伤害
        self.hp -= actual_damage

        # 检查是否达到夺取阈值 - 自动转变阵营
        if (self.capture_hp_threshold > 0 and  # 只有当明确设置了大于0的阈值时才可被夺取
            self.hp > 0 and  # 确保目标没有死亡
            (self.hp * 100 / self.hp_max) <= self.capture_hp_threshold):  # 检查血量是否低于阈值

            # 执行自动转变阵营
            old_player = self.player
            if attacker is not None:
                self.set_player(attacker.player)
            
            # 通知双方玩家
            if notify:
                # 对于被占领方播放被占领音效
                if old_player and hasattr(old_player, 'interface'):
                    self.notify("captured_lost")  # 播放被占领音效
                
                # 对于占领方播放占领成功音效
                if attacker and hasattr(attacker, 'notify'):
                    attacker.notify("captured_success")  # 播放占领成功音效
            return

        # 发送通知
        if notify and attacker is not None:
            self._send_hit_notification(attacker, actual_damage)
        
        # 处理死亡或受伤状态
        if self.hp <= 0:
            self.die(attacker)
        else:
            self.player.on_unit_attacked(self, attacker)

    def _notify_guard_units(self, attacker):
        """通知警戒模式的友军单位"""
        # 通知当前区域的友军
        self._notify_units_in_place(self.place, attacker)
        # 通知相邻区域的友军
        for neighbor in self.place.neighbors:
            self._notify_units_in_place(neighbor, attacker)

    def _notify_units_in_place(self, place, attacker):
        """通知指定区域中的友军单位"""
        for unit in place.objects:
            if (unit != self and 
                unit.player == self.player and 
                isinstance(unit, Creature) and 
                unit.ai_mode == "guard" and 
                getattr(unit, 'counterattack_enabled', False)):
                unit.last_attacker = attacker

    def _calculate_actual_damage(self, damage, attacker):
        """计算实际伤害值"""
        if attacker is None:
            return damage
            
        is_melee = self.in_melee_range(attacker) if hasattr(self, 'in_melee_range') else True
        total_defense = (
            self._get_total_melee_defense_vs(attacker)
            if is_melee else
            self._get_total_ranged_defense_vs(attacker)
        )
        
        return max(max(0, damage - total_defense), self.minimal_damage)

    def _send_hit_notification(self, attacker, actual_damage):
        """发送受击通知"""
        if attacker.is_inside:
        # 如果攻击者在容器内，使用攻击者自己的类型和ID
            attacker_type = attacker.type_name
            attacker_id = attacker.id
        else:
        # 正常情况下使用容器的信息
            attacker_type = attacker.type_name
            attacker_id = attacker.id
            
        self._raise_subsquare_threat(actual_damage)
        
        # 判断攻击类型
        is_melee = not (hasattr(attacker, 'rdg_range') and attacker.rdg_range > 0)
        attack_type = "mdg" if is_melee else "rdg"
        
        # 获取伤害等级并添加详细调试日志
        damage_level = getattr(attacker, f'{attack_type}_level', 0)
        
        # 发送通知
        self.notify(
            f"wounded,{attacker.type_name},{attacker.id},{damage_level}"
        )


    def delete(self):
        Entity.delete(self)
        self.set_player(None)

    def on_disappear(self):
        """当召唤单位时间到期消失时调用"""
        self.notify("disappear")  # 只发送消失通知
        self.delete()  # 直接删除，不调用 die()

    def die(self, attacker=None, notify_death=True):
        """
        处理单位死亡
        attacker: 击杀者（如果是被击杀）
        notify_death: 是否发送死亡通知(被击杀时为True)
        """
        # remove transported units
        if self.inside:
            for o in self.inside.objects[:]:
                o.move_to(self.place, self.x, self.y)
                if o.place is self.inside:  # not enough space
                    o.collision = 0
                    o.move_to(self.place, self.x, self.y)
                if self.airground_type != "ground":
                    o.die(attacker)

        # 只在被击杀时发送死亡通知和处理统计
        if notify_death:
            self.notify("death")
            self.player.stats.add("lost", self.stat_type)
            if attacker is not None:
                self.notify("death_by,%s" % attacker.id)
                self.player.on_unit_attacked(self, attacker)
                attacker.player.stats.add("killed", self.stat_type)

        self.delete()

    heal_level = 0

    def heal_nearby_units(self):
        # level 1 of healing: 1 hp every 7.5 seconds
        hp = self.heal_level * PRECISION // 25
        allies = self.player.allied
        units = self.world.get_objects2(
            self.x,
            self.y,
            6 * PRECISION,
            filter=lambda x: x.is_healable and x.hp < x.hp_max,
            players=allies,
        )
        for u in units:
            u.hp = min(u.hp_max, u.hp + hp)

    harm_target_type = ()

    def _can_harm(self, other):
        return self.world.can_harm(self.type_name, other.type_name)

    def harm_nearby_units(self):
        # level 1: 1 hp every 7.5 seconds
        hp = self.harm_level * PRECISION // 25
        units = self.world.get_objects2(
            self.x,
            self.y,
            6 * PRECISION,
            filter=lambda x: x.is_vulnerable and self._can_harm(x),
        )
        for u in units:
            u.receive_hit(hp, self, notify=False)

    def is_an_enemy(self, c):
        if isinstance(c, Creature):
            if (
                self.has_imperative_orders()
                and self.orders[0].__class__ == GoOrder
                and self.orders[0].target is c
            ):
                return True
            else:
                return self.player and self.player.player_is_an_enemy(c.player)
        else:
            return False

    def _can_attack_from_inside(self):
        """检查单位是否可以从载具内部进行攻击"""
        # 如果不在载具内,允许攻击
        if not self.is_inside:
            return True
            
        # 获取载具对象
        container = self.place.container
        if not container:
            return False
            
        # 检查是否允许所有单位攻击
        if hasattr(container, 'allow_units_attack'):
            if 'all' in container.allow_units_attack:
                return True
                
            # 检查特定单位类型
            return (self.type_name in container.allow_units_attack or 
                    any(t in container.allow_units_attack for t in getattr(self, 'expanded_is_a', [])))
                    
        return False  # 默认不允许在载具内攻击

    def can_be_captured(self):
        """检查单位是否可以被夺取"""
        return (self.capture_hp_threshold > 0 and 
                self.hp > 0 and 
                (self.hp * 100 / self.hp_max) <= self.capture_hp_threshold)

    def can_attack_if_in_range(self, other):
        """
        检查是否可以攻击目标（假设目标在攻击范围内）
        
        Args:
            other: 目标单位
            
        Returns:
            bool: 是否可以攻击
        """
# 检查是否有任何攻击能力
        has_attack = (self.mdg > 0) or (self.rdg > 0)
        if not has_attack:
            return False
            
        # 检查目标是否在感知范围内
        if other not in self.player.perception:
            return False
            
        # 检查目标是否有效
        if (
            other is None
            or other.place is None
            or getattr(other, "hp", 0) < 0
        ):
            return False
            
        # 获取目标的地面/空中属性
        target_type = ground_or_air(getattr(other, "airground_type", None))
        
        # 检查目标类型是否可攻击
        can_melee = (self.mdg > 0) and (target_type in getattr(self, "mdg_targets", ["ground"]))
        can_ranged = (self.rdg > 0) and (target_type in getattr(self, "rdg_targets", ["ground"]))
        
        if not (can_melee or can_ranged):
            return False
            
        # 检查目标是否可被攻击
        if not other.is_vulnerable:
            return False
            
        return True

    def _can_attack(self, target):
        # 检查目标是否在攻击范围内
        if not self.in_attack_range(target):
            return False
            
        # 如果目标在容器内
        if target.is_inside:
            container = target.place.container
            # 如果容器阻挡了出口
            if hasattr(container, 'blocked_exit'):
                exit = container.blocked_exit
                # 如果攻击者在出口任意一侧都可以攻击
                if (self.place is container.place or  # 攻击者在容器所在区域
                    (exit and self.place is exit.other_side.place)):  # 攻击者在出口另一侧
                    return True
                    
        # 检查目标是否在当前区域或相邻区域
        return (target.place is self.place or 
                target.place in self.place.neighbors)

    # ... rest of the class ...

    def can_attack(self, target):
        """检查是否可以攻击目标"""
        if not target or target.player is self.player:
            return False
            
        # 检查是否可以从载具内攻击
        if not self._can_attack_from_inside():
            return False
            
        return True

    def can_attack(self, other):  # without moving to another square
        if not self.can_attack_if_in_range(other):
            return False
        # 如果是近战单位（射程为0）且在同一区域，允许攻击
        if ((self.mdg_range == 0 and self.mdg > 0) or 
            (self.rdg_range == 0 and self.rdg > 0)) and other.place is self.place:
            return True
        if self.speed and other.place is self.place:
            return True
        return self._near_enough_to_aim(other)

    def _choose_enemy(self, place):
        """Choose enemy to attack
        Prioritize: higher menace -> closer distance -> lower ID
        """
        known = self.player.known_enemies(place)
        if not known:
            for place in place.strict_neighbors:
                known = self.player.known_enemies(place)
                if known:
                    break
        reachable_enemies = [x for x in known if self.can_attack(x)]
        if reachable_enemies:
            reachable_enemies.sort(
                key=lambda x: (
                    -x.menace,
                    square_of_distance(self.x, self.y, x.x, x.y),
                    x.id,
                )
            )
            self._attack(reachable_enemies[0])
            return True

    def _attack(self, target):
        # don't notify or attack if already attacking the same target
        # (at the moment, this test is necessary if the target is not a menace, for example a farm)
        if not isinstance(self.action, AttackAction) or self.action.target != target:
            self.action = AttackAction(self, target)
            self.notify("attack")

    def flee(self):
        sl = [e.other_side.place for e in self.place.exits]
        if self._previous_square:
            sl.insert(0, self._previous_square)
        for s in sl:
            if self.player.balance(s, add=self, mult=100) > self.player.balance(
                self.place, mult=100
            ):
                self.notify("flee")
                self.take_order(["go", s.id], imperative=True)
                break

    def decide(self):
        # 如果在载具内，选择载具位置的敌人
        if self.is_inside:
            self._choose_enemy(self.place.container.place)
            return

        # 智能单位或防御模式下的撤退判断
        if (
            (self.player.smart_units or self.ai_mode == "defensive")
            and self.speed > 0
            and not self._must_hold()
            and self.player.balance(self.place, self._previous_square, mult=10) < 5
        ):
            self.flee()
            return

        # 检查是否有任何攻击能力
        has_attack = (self.mdg > 0) or (self.rdg > 0)
        if not has_attack:
            return

    # 站岗模式：根据反击开关决定行为
        if self.ai_mode == "guard":
            if self.last_attacker is not None and self.last_attacker.place is not None:
            # 如果开启了反击，持续追踪攻击者
                if getattr(self, 'counterattack_enabled', False):
                    if self.in_attack_range(self.last_attacker):
                        self._choose_enemy(self.last_attacker.place)
                    else:
                    # 如果敌人超出攻击范围，可以适当追击
                        self.take_order(["go", self.last_attacker.place.id], imperative=True)
            # 如果没开启反击，只进行一次反击
                else:
                    if self._choose_enemy(self.last_attacker.place):
                        self.last_attacker = None  # 反击一次后重置
            return

        # 追击模式：主动追击视野内的敌人或响应友军受攻击
        if self.ai_mode == "chase":
            # 如果开启了反击且有友军受到攻击，优先响应
            if (getattr(self, 'counterattack_enabled', False) and 
                self.last_attacker is not None and 
                self.last_attacker.place is not None):
                if self.in_attack_range(self.last_attacker):
                    self._choose_enemy(self.last_attacker.place)
                else:
                    self.take_order(["go", self.last_attacker.place.id], imperative=True)
                return

            # 搜索视野范围内的敌人
            closest_enemy = None
            min_distance = float('inf')
            
            # 先检查当前位置
            if self._choose_enemy(self.place):
                return
                
            # 然后检查相邻区域
            for p in self.place.neighbors:
                for unit in p.objects:
                    if unit.player is not None and self.player.is_an_enemy(unit):
                        dist2 = square_of_distance(self.x, self.y, unit.x, unit.y)
                        sight_range2 = (self.sight_range + unit.radius) ** 2
                        if dist2 <= sight_range2 and dist2 < min_distance:
                            min_distance = dist2
                            closest_enemy = unit
                            
            if closest_enemy:
                if self.in_attack_range(closest_enemy):
                    self._attack(closest_enemy)
                else:
                    # 只有当敌人不在攻击范围内时才移动
                    self.take_order(["go", closest_enemy.place.id], imperative=True)
            return

        # 选择当前位置的敌人
        if self._choose_enemy(self.place):
            return

        # 选择相邻位置的敌人
        for p in self.place.neighbors:
            if self._choose_enemy(p):
                break

    def _get_squares_in_sight(self):
        """获取单位视野范围内的所有区域"""
        squares = set([self.place])  # 当前区域

        # 添加相邻区域
        for p in self.place.neighbors:
            squares.add(p)

        # TODO: 根据视野范围(sight_range)添加更远的区域
    
        return squares

    def in_attack_range(self, target):
        """检查目标是否在攻击射程内"""
        if target is None:
            return False
        dist2 = square_of_distance(self.x, self.y, target.x, target.y)
        collision = self.radius + target.radius
        
        # 如果是近战单位（射程为0），只要在同一个区域就视为在攻击范围内
        if (self.mdg_range == 0 and self.mdg > 0) or (self.rdg_range == 0 and self.rdg > 0):
            return target.place is self.place
            
        if self.mdg_range > 0:
            max_range2 = (self.mdg_range + collision) ** 2
            if dist2 <= max_range2:
                return True
                
        if self.rdg_range > 0:
            max_range2 = (self.rdg_range + collision) ** 2
            if dist2 <= max_range2:
                return True
                
        return False

    # attack

    def hit(self, target):
        base_damage = self._base_damage_versus(target)
        damage = max(self.minimal_damage, base_damage - target.armor_versus(self))
        target.receive_hit(damage, self)

    def armor_versus(self, attacker):
        d = self.armor_vs
        if attacker.type_name in d:
            return d[attacker.type_name]
        for t in attacker.expanded_is_a:
            if t in d:
                return d[t]
        return self.armor

    def _base_damage_versus(self, target):
        d = self.damage_vs
        if target.type_name in d:
            return d[target.type_name]
        for t in target.expanded_is_a:
            if t in d:
                return d[t]
        return self.damage

    def _hit_or_miss(self, target):
        """命中判定
        
        返回值:
            bool: True表示命中，False表示未命中
        """
        # 预先判断是否为近战还是远程攻击
        is_melee = not (hasattr(self, 'rdg_range') and self.rdg_range > 0 and self.in_ranged_range(target))
        
        # 获取攻击者的命中修正
        cover = self._get_melee_cover_vs(target) if is_melee else self._get_ranged_cover_vs(target)
        
        # 获取目标在地形上的闪避修正
        target_dodge_on_terrain = target._get_dodge_on_terrain(is_melee)
        
        # 获取目标对攻击者的固有闪避修正
        target_dodge_vs = 0
        if is_melee and hasattr(target, 'mdg_dodge_vs'):
            if self.type_name in target.mdg_dodge_vs:
                target_dodge_vs = target.mdg_dodge_vs[self.type_name]
            elif hasattr(self, 'expanded_is_a'):
                for t in self.expanded_is_a:
                    if t in target.mdg_dodge_vs:
                        target_dodge_vs = target.mdg_dodge_vs[t]
                        break
        elif not is_melee and hasattr(target, 'rdg_dodge_vs'):
            if self.type_name in target.rdg_dodge_vs:
                target_dodge_vs = target.rdg_dodge_vs[self.type_name]
            elif hasattr(self, 'expanded_is_a'):
                for t in self.expanded_is_a:
                    if t in target.rdg_dodge_vs:
                        target_dodge_vs = target.rdg_dodge_vs[t]
                        break
        
        # 获取目标的基础闪避值
        base_dodge = target.mdg_dodge // 1000 if is_melee else target.rdg_dodge // 1000
        
        # 计算最终命中率和基础闪避率
        hit_chance = cover - base_dodge - target_dodge_on_terrain - target_dodge_vs
        total_dodge = base_dodge + target_dodge_on_terrain + target_dodge_vs
        hit_chance = max(min(hit_chance, 100), 0)  # 限制在0-100范围内
        
        # 投掷随机数判定是否命中
        roll = random.randint(1, 100)
        result = roll <= hit_chance
        
        # 通知逻辑
        if result:
            return True  # 命中
        elif roll <= cover:
            # 命中修正范围内但被闪避，发送闪避通知
            target.notify(f"dodge,{self.type_name},{1 if is_melee else 0}")
        else:
            # 完全落空，发送未命中通知
            target.notify(f"missed,{self.type_name},{1 if is_melee else 0}")
        return False


    def splash_aim(self, target, is_melee=True):
        """
        改进的溅射伤害计算:
        1. 根据距离计算衰减
        2. 随机分配伤害
        3. 添加溅射效果通知
        """
        if target.place is None or target.place.objects is None:
            return

        # 获取溅射属性
        if is_melee:
            splash_range = self.mdg_radius
            total_splash = self.mdg_splash
        else:
            splash_range = self.rdg_radius
            total_splash = self.rdg_splash

        if splash_range <= 0 or total_splash <= 0:
            return

        radius2 = splash_range * splash_range
        # 根据攻击类型选择衰减系数
        splash_decay_min = self.mdg_splash_decay_min if is_melee else self.rdg_splash_decay_min

        # 收集范围内目标并计算距离系数
        victims_with_factors = []
        for obj in target.place.objects[:]:
            if obj is self or obj is target:
                continue
            if not self.is_an_enemy(obj) or not isinstance(obj, Creature):
                continue
                
            dist2 = square_of_distance(self.x, self.y, obj.x, obj.y)
            if dist2 <= radius2:
                # 使用对应类型的衰减系数
                decay_range = 1.0 - splash_decay_min
                dist_factor = 1.0 - (math.sqrt(dist2) / splash_range * decay_range)
                victims_with_factors.append((obj, dist_factor))

        if not victims_with_factors:
            return

        # 生成随机权重，但考虑距离因素
        n = len(victims_with_factors)
        rands = []
        for _, factor in victims_with_factors:
            # 距离越近，随机范围越大
            rand_max = 0.5 + (factor * 0.5)  # 0.5 ~ 1.0
            rands.append(random.random() * rand_max)
            
        sumRand = sum(rands)
        
        if sumRand == 0:
            # 平均分配，但考虑距离衰减
            for (victim, factor), _ in zip(victims_with_factors, rands):
                damage = int(round(total_splash * factor / n))
                if damage > 0:
                    victim.receive_hit(damage, self, notify=True)
                    victim.notify("splash_hit")
        else:
            # 随机分配，但受距离影响
            distributedSum = 0
            for (victim, factor), rand in zip(victims_with_factors, rands):
                portion = int(round(rand / sumRand * total_splash * factor))
                distributedSum += portion
                if portion > 0:
                    victim.receive_hit(portion, self, notify=True)
                    victim.notify("splash_hit")
            
            # 处理剩余伤害
            leftover = total_splash - distributedSum
            if leftover > 0:
                # 优先补给最近的目标
                closest_victim = max(victims_with_factors, key=lambda x: x[1])[0]
                closest_victim.receive_hit(leftover, self, notify=True)

    def chance_to_hit(self, target):
        """计算基础命中率(0~100)"""
        # 获取是否为近战攻击
        is_melee = self.in_melee_range(target)
        
        # 1. 获取基础命中率
        if is_melee:
            base_chance = self._get_melee_cover_vs(target)
        else:
            base_chance = self._get_ranged_cover_vs(target)
            
        # 2. 应用地形修正
        terrain_type = target.place.type_name
        if terrain_type:
            if is_melee and self.mdg_cover_on_terrain:
                # 检查是否有针对该地形的近战命中修正
                try:
                    idx = self.mdg_cover_on_terrain.index(terrain_type)
                    if idx + 1 < len(self.mdg_cover_on_terrain):
                        terrain_modifier = int(self.mdg_cover_on_terrain[idx + 1])
                        base_chance = base_chance * terrain_modifier // 100
                except ValueError:
                    pass
            elif not is_melee and self.rdg_cover_on_terrain:
                # 检查是否有针对该地形的远程命中修正
                try:
                    idx = self.rdg_cover_on_terrain.index(terrain_type)
                    if idx + 1 < len(self.rdg_cover_on_terrain):
                        terrain_modifier = int(self.rdg_cover_on_terrain[idx + 1])
                        base_chance = base_chance * terrain_modifier // 100
                except ValueError:
                    pass
        
        # 3. 处理高地修正
        high_ground = (
            not self.place.high_ground
            and target.place.high_ground
            and target.airground_type == "ground"
            and self.height < target.height
        )
        
        if high_ground:
            is_projectile = (is_melee and hasattr(self, 'mdg_projectile') and self.mdg_projectile) or \
                           (not is_melee and hasattr(self, 'rdg_projectile') and self.rdg_projectile)
            if is_projectile:
                base_chance //= 2  # 投射物攻击打高地命中率减半

        # 4. 处理地形掩护修正
        if not is_melee:
            terrain_cover = target.place.terrain_cover[
                0 if target.airground_type != "air" else 1
            ]
            base_chance = base_chance * (100 - terrain_cover) // 100

        return base_chance

    def has_hit(self, target) -> bool:
        """
        判定是否命中：
          1) 攻击方 'chance_to_hit' 得到基础命中率 (0~100)
          2) 目标 'dodge' 得到闪避率 (0~100)
          3) 最终命中率 = 命中率 * (100 - dodge) / 100
          4) 随机掷 1~100 <= 最终命中率 => 命中，否则 Miss
        """
        return self._hit_or_miss(target)


    # orders

    def take_order(self, o, forget_previous=True, imperative=False, order_id=None):
        # an imperative "go" order on a unit is an "attack" order
        # note: this could be done by the user interface
        if imperative and o[0] == "go":
            target = self.player.get_object_by_id(o[1])
            if getattr(target, "player", None) is not None:
                o[0] = "attack"
        if self.is_inside:
            self.notify("order_impossible")
            return
        cls = ORDERS_DICT.get(o[0])
        if cls is None:
            warning("unknown order: %s", o)
            return
        if not cls.is_allowed(self, *o[1:]):
            self.notify("order_impossible")
            return
        if forget_previous and not cls.never_forget_previous:
            self.cancel_all_orders()
        order = cls(self, o[1:])
        order.id = order_id
        if imperative:
            order.is_imperative = imperative
        order.immediate_action()

    def get_default_order(self, target_id):
        target = self.player.get_object_by_id(target_id)
        if not target:
            return
        elif getattr(target, "is_an_exit", False):
            return "block"
        elif getattr(target, "player", None) is self.player and self.have_enough_space(
            target
        ):
            return "load"
        elif getattr(target, "player", None) is self.player and target.have_enough_space(self):
            return "enter"
        elif "gather" in self.basic_skills and isinstance(target, Deposit):
            return "gather"
        elif (
            isinstance(target, BuildingSite)
            and target.type.__name__ in self.can_build
            or hasattr(target, "is_repairable")
            and target.is_repairable
            and target.hp < target.hp_max
            and self.can_build
        ) and not self.is_an_enemy(target):
            return "repair"
        elif RallyingPointOrder.is_allowed(self):
            return "rallying_point"
        elif GoOrder.is_allowed(self):
            return "go"

    def take_default_order(
        self, target_id, forget_previous=True, imperative=False, order_id=None
    ):
        order = self.get_default_order(target_id)
        if order:
            self.take_order([order, target_id], forget_previous, imperative, order_id)

    def check_if_enough_resources(self, cost, food=0):
        for i, c in enumerate(cost):
            if self.player.resources[i] < c:
                return f"not_enough_resource{i+1}"
        if (
            not self.orders
            and food > 0
            and self.player.available_food < self.player.used_food + food
        ):
            if self.player.available_food < self.world.food_limit:
                return "not_enough_food"
            else:
                return "population_limit_reached"

    def cancel_all_orders(self, unpay=True):
        while self.orders:
            self.orders.pop().cancel(unpay)

    def must_build(self, order):
        for o in self.orders:
            if o == order:
                return True

    def _put_building_site(self, type, target):
        # if the target is a memory, get the true object instead
        if getattr(target, "is_memory", False):
            target = target.initial_model
        # remember before deletion
        place, x, y, _id = target.place, target.x, target.y, target.id
        if not hasattr(place, "place"):  # target is a square
            place = target
        if not (getattr(target, "is_an_exit", False) or type.is_buildable_anywhere):
            target.delete()  # remove the meadow replaced by the building
            remember_land = True
        else:
            remember_land = False
        site = BuildingSite(self.player, place, x, y, type)
        if remember_land:
            site.building_land = target
        if getattr(target, "is_an_exit", False):
            site.block(target)

        # update the orders of the workers
        order = self.orders[0]
        for unit in self.player.units:
            if unit is self:
                continue
            for n in range(len(unit.orders)):
                if unit.orders[n] == order:
                    # help the first worker
                    unit.orders[n] = BuildPhaseTwoOrder(unit, [site.id])
                    unit.orders[n].on_queued()
        self.orders[0] = BuildPhaseTwoOrder(self, [site.id])
        self.orders[0].on_queued()

    def _delta(self, total, percentage):
        # Initial formula (reordered for a better precision):
        # delta = (percentage / 100) * total / (self.time_cost / VIRTUAL_TIME_INTERVAL)
        try:
            delta = int(
                total * percentage * VIRTUAL_TIME_INTERVAL // self.time_cost // 100
            )
        except ZeroDivisionError:
            delta = int(total * percentage * VIRTUAL_TIME_INTERVAL // 100)
        if delta == 0 and total != 0:
            warning("insufficient precision (delta: %s total: %s)", delta, total)
        return delta

    @property
    def hp_delta(self):
        return self._delta(self.hp_max, 70)

    @property
    def repair_cost(self):  # per turn
        return (self._delta(c, 30) for c in self.cost)

    def be_built(self, actor):
        if self.hp < self.hp_max:
            result = actor.check_if_enough_resources(self.repair_cost)
            if result is not None:
                actor.notify("order_impossible,%s" % result)
                actor.orders[0].mark_as_complete()
            else:
                actor.player.pay(self.repair_cost)
                self.hp = min(self.hp + self.hp_delta, self.hp_max)

    @property
    def is_fully_repaired(self):
        return getattr(self, "is_repairable", False) and self.hp == self.hp_max

    # transport

    def have_enough_space(self, target):
        if self.inside:
            return self.inside.have_enough_space(target)

    def load(self, target):
        # 记录原始位置
        original_place = target.place
        original_x = target.x 
        original_y = target.y

        # 保存原始坐标到目标对象
        target.original_x = original_x
        target.original_y = original_y

        # 如果载具定义了属性加成
        if hasattr(self, 'allow_units_add'):
            # 确保 allow_units_add 是字典类型
            if isinstance(self.allow_units_add, list):
                allow_units_add = {}
                i = 0
                while i < len(self.allow_units_add):
                    if i + 1 < len(self.allow_units_add):
                        allow_units_add[self.allow_units_add[i]] = float(self.allow_units_add[i + 1])
                    i += 2
                self.allow_units_add = allow_units_add
                
        # 对每个属性应用加成
            for stat, value in self.allow_units_add.items():
                if hasattr(self, stat):
                    # 初始化加成统计
                    if stat not in self._bonus_stats:
                        self._bonus_stats[stat] = 0

                # 为每个装载的单位累加加成
                    current_value = getattr(self, stat)
                    if isinstance(current_value, (int, float)):
                    # 对于速度和伤害属性，需要特殊处理
                        if stat == 'speed' or stat in ('mdg', 'rdg', 'mdf', 'rdf', 'mdg_vs', 'rdg_vs', 'mdf_vs', 'rdf_vs', 'mdg_delay', 'rdg_delay', 'mdg_cd', 'rdg_cd', 'mdg_cd_vs', 'rdg_cd_vs', 'mdg_ready', 'rdg_ready', 'mdg_ready_vs', 'rdg_ready_vs', 'mdg_range', 'rdg_range', 'mdg_range_vs', 'rdg_range_vs', 'mdg_minimal_range', 'rdg_minimal_range', 'mdg_minimal_range_vs', 'rdg_minimal_range_vs', 'mdg_splash', 'rdg_splash', 'mdg_radius', 'rdg_radius'):
                        # 如果当前值小于100，说明是正常值
                            if current_value < 100:
                                bonus_value = float(value) * 1000
                            else:  # 否则说明是内部值（已经乘以1000的）
                                bonus_value = float(value) * 1000
                        else:
                            bonus_value = float(value)
                        
                        self._bonus_stats[stat] += bonus_value
                        new_value = current_value + bonus_value
                        setattr(self, stat, new_value)
                        print(f"DEBUG: {self.type_name} {stat} increased by {bonus_value} to {new_value}")

        # 取消所有命令并移动到运输单位内
        target.cancel_all_orders()
        target.notify("enter")
        target.move_to(self.inside, 0, 0)

        # 在原位置生成草地,但先检查是否已存在
        if not target.is_buildable_anywhere:
            # 检查该位置是否已有草地
            has_meadow = False
            for obj in original_place.objects:
                if (obj.is_a_building_land and 
                    obj.x == original_x and 
                    obj.y == original_y):
                    has_meadow = True
                    break
                    
            # 只在没有草地时创建新的
            if not has_meadow:
                from .worldresource import Meadow
                Meadow(original_place, original_x, original_y)

    def load_all(self, place=None):
        if place is None:
            place = self.place
        # 按运输容量从大到小排序单位
        sorted_units = sorted(
            [u for u in self.player.units if u.place is place and u != self],
            key=lambda x: x.transport_volume,
            reverse=True
        )
    
    # 尝试装载每个单位
        for unit in sorted_units:
            if self.have_enough_space(unit):
                self.load(unit)
            
    # 发送装载完成通知
        self.notify("order_ok")

    def unload_all(self, place=None):
        if place is None:
            place = self.place
            x = self.x
            y = self.y
        else:
            x = place.x
            y = place.y

        # 移除属性加成
        if self.allow_units_add:
            for stat, value in self.allow_units_add.items():
                if stat in self._bonus_stats:
                    current_value = getattr(self, stat)
                    total_bonus = self._bonus_stats[stat]
                    
                    # 对于速度属性，需要特殊处理
                    if stat == 'speed':
                        if current_value < 100:
                            new_value = current_value - total_bonus
                        else:
                            new_value = current_value - (total_bonus * 1000)
                    else:
                        new_value = current_value - total_bonus
                        
                    setattr(self, stat, new_value)
                    self._bonus_stats[stat] = 0
                    del self._bonus_stats[stat]
                    print(f"DEBUG: {self.type_name} {stat} reset from {current_value} to {new_value}")

        # 检查是否有需要草地的建筑
        has_building_needs_meadow = False
        for obj in self.inside.objects:
            if not obj.is_buildable_anywhere:
                has_building_needs_meadow = True
                break

        # 如果有需要草地的建筑，检查目标位置是否有草地
        if has_building_needs_meadow:
            meadows = []
            for obj in place.objects:
                if obj.is_a_building_land:
                    meadows.append(obj)
            if not meadows:
                self.notify("order_impossible")
                return

        # 执行卸载
        for obj in self.inside.objects[:]:
            if not obj.is_buildable_anywhere:
                # 如果是建筑，选择一个可用的草地
                available_meadows = [m for m in meadows if m in place.objects]
                if not available_meadows:
                    continue
                meadow = available_meadows[0]  # 取第一个可用的草地
                obj_x = meadow.x
                obj_y = meadow.y
                meadow.delete()
            else:
                # 如果是普通单位，寻找空闲位置
                obj_x, obj_y = place.find_free_space_for(obj, x, y)
                if obj_x is None:
                    # 如果没有找到空闲位置，尝试在附近找一个位置
                    for dx in range(-1, 2):
                        for dy in range(-1, 2):
                            test_x = x + dx
                            test_y = y + dy
                            if place.contains(test_x, test_y):
                                obj_x, obj_y = place.find_free_space_for(obj, test_x, test_y)
                                if obj_x is not None:
                                    break
                        if obj_x is not None:
                            break
                                    
                    if obj_x is None:
                        # 如果还是找不到位置，跳过这个单位
                        continue
            
            # 移动对象到目标位置
            obj.move_to(place, obj_x, obj_y)
            obj.notify("exit")

    #

    def stop(self):
        self.action_target = None
        self.position_to_hold = None

    @property
    def is_idle(self):
        return self.action_target is None



class Unit(Creature):

    food_cost = 1

    is_cloakable = True
    is_a_gate = True
    is_a_unit = True

    def die(self, attacker=None):
        if self.corpse:
            Corpse(self)
        Creature.die(self, attacker)

    @property
    def basic_skills(self):
        for o in self.orders:
            if isinstance(o, UpgradeToOrder):
                return set()
        return self._basic_skills

    # actions

    def next_square(self, target, avoid=False):
        next_stage = self.next_stage(target, avoid=avoid)
        try:
            return next_stage.other_side.place
        except AttributeError:
            return next_stage

    def next_stage(self, target, avoid=False):
        if self.is_inside:
            return
        if target is None or target.place is None:
            return None
        if not isinstance(target, Square):
            if self.place == target.place:
                return target
            place = target.place
        else:
            if self.place == target:
                return None
            place = target
        if not isinstance(place, Square):
            return None
        self.distance_to_goal = self.place.shortest_path_distance_to(
            place, player=self.player, plane=self.airground_type, avoid=avoid
        )
        return self.place.shortest_path_to(
            place, player=self.player, plane=self.airground_type, avoid=avoid
        )

    def start_moving_to(self, target, avoid=False):
        # note: it can be an attack
        # note: several calls might be necessary
        self.action_target = self.next_stage(target, avoid=avoid)

    def _next_stage_to_enemy(self):
        for e in self.place.exits:
            if e.other_side.place.contains_enemy(self.player):
                return e
        return self.next_stage(self.world.random.choice(self.world.squares))

    def start_moving_to_enemy(self):
        if self.place.contains_enemy(self.player):
            self._choose_enemy(self.place)
        else:
            self.action_target = self._next_stage_to_enemy()

    _destination = None

    def auto_explore(self) -> None:
        assert self.player is not None
        if not self.action_target:
            if self.place is not self._destination:
                self.action_target = self.next_stage(self._destination, avoid=True)
                if self.action_target is not None:
                    return
            for place in self.player.unknown_starting_squares:
                self.action_target = self.next_stage(place, avoid=True)
                if self.action_target is not None:
                    self._destination = place
                    return
            for place in self.player.unknown_squares[:10]:
                self.action_target = self.next_stage(place, avoid=True)
                if self.action_target is not None:
                    self._destination = place
                    return
            for place in self.player.squares_to_watch[:10]:
                self.action_target = self.next_stage(place, avoid=True)
                if self.action_target is not None:
                    self._destination = place
                    return
            # any square
            self._destination = self.world.random.choice(self.world.squares)
            self.action_target = self.next_stage(self._destination)
        elif self.player.is_very_dangerous(self.action_target):
            if not self.player.is_very_dangerous(self.place):
                self.action_target = None
        elif self.player.is_very_dangerous(self.place):
            if self._previous_square is not None and not self.player.is_very_dangerous(
                self._previous_square
            ):
                self.start_moving_to(self._previous_square)

    def move_on_border(self, e):
        self.move_to(e.place, e.x, e.y)

    def block(self, e):
        if not self.blocked_exit:
            self.blocked_exit = e
            e.add_blocker(self)


class Worker(Unit):

    ai_mode = "defensive"
    auto_gather = True
    auto_repair = True
    can_switch_ai_mode = True
    _basic_skills = {"go", "attack", "gather", "repair", "block", "join_group"}
    is_teleportable = True
    cargo = None  # gathered resource
    stat_type = "unit"

    def decide(self):
        Unit.decide(self)
        if self.player.__class__.__name__ != "Human":
            return
        if self.orders and self.orders[0].keyword != "gather":
            return
        if self.auto_repair:
            for p in self.player.allied:
                for u in p.units:
                    if (
                        u.place is self.place
                        and u.is_repairable
                        and u.hp < u.hp_max
                        and not isinstance(u, BuildingSite)
                        and self.check_if_enough_resources(u.repair_cost) is None
                    ):
                        self.take_order(["repair", u.id])
                        return
        if self.orders:
            return
        if self.auto_gather:
            local_warehouses_resource_types = set()
            for w in self.place.objects:
                if w.player in self.player.allied:
                    local_warehouses_resource_types.update(w.storable_resource_types)
            if local_warehouses_resource_types:
                deposits = [
                    o
                    for o in self.place.objects
                    if isinstance(o, Deposit)
                    and o.resource_type in local_warehouses_resource_types
                ]
                if deposits:
                    if (
                        self.cargo
                        and self.cargo[0] not in local_warehouses_resource_types
                    ):
                        self.cargo = None
                    o = self.world.random.choice(deposits)
                    self.take_order(["gather", o.id])


class Soldier(Unit):

    ai_mode = "offensive"
    can_switch_ai_mode = True
    _basic_skills = {"go", "attack", "patrol", "block", "join_group"}
    is_teleportable = True
    stat_type = "unit"


class Effect(Unit):
    collision = 0
    corpse = 0
    food_cost = 0
    is_vulnerable = False
    presence = 0
    _basic_skills: Set[str] = set()

    def die(self, attacker=None):
        self.delete()


class _Building(Creature):

    ai_mode = "offensive"
    can_switch_ai_mode = False  # never flee

    is_repairable = True  # or buildable (in the case of a BuildingSite)
    is_healable = False
    is_a_building = True

    transport_volume = 99

    corpse = 0

    def die(self, attacker=None):
        place, x, y = self.place, self.x, self.y
        Creature.die(self, attacker)
        if self.building_land:
            self.building_land.move_to(place, x, y)


class BuildingSite(_Building):

    type_name = "buildingsite"
    basic_skills = {"cancel_building"}

    def __init__(self, player, place, x, y, building_type):
        super().__init__(player, place, x, y)
        player.pay(building_type.cost)
        self.type = building_type
        self.hp_max = building_type.hp_max
        self._starting_hp = building_type.hp_max * 5 // 100
        self.hp = self._starting_hp
        self.timer = building_type.time_cost // VIRTUAL_TIME_INTERVAL
        self.damage_during_construction = 0

    def receive_hit(self, attacker, *args, **kargs):
        """接收来自攻击者的伤害"""
        # 判断是近战还是远程攻击
        is_melee = attacker.in_melee_range(self) if hasattr(attacker, 'in_melee_range') else True
        
        # 根据攻击类型获取伤害值
        if is_melee and hasattr(attacker, 'mdg'):
            damage = attacker.mdg
        elif not is_melee and hasattr(attacker, 'rdg'):
            damage = attacker.rdg
        else:
            damage = 0
            
        self.damage_during_construction += damage
        _Building.receive_hit(self, attacker, *args, **kargs)

    @property
    def is_buildable_anywhere(self):
        return self.type.is_buildable_anywhere

    @property
    def is_buildable_on_exits_only(self):
        return self.type.is_buildable_on_exits_only

    @property
    def is_buildable_near_water_only(self):
        return self.type.is_buildable_near_water_only

    @property
    def is_a_gate(self):
        return self.type.is_a_gate

    @property
    def time_cost(self):
        return self.type.time_cost

    @property
    def hp_delta(self):
        return self._delta(self.hp_max - self._starting_hp, 100)

    def be_built(self, actor):
        self.hp = min(self.hp + self.hp_delta, self.hp_max)
        self.timer -= 1
        if self.timer == 0:
            player, place, x, y, hp = self.player, self.place, self.x, self.y, self.hp
            blocked_exit = self.blocked_exit
            self.delete()
            building = self.type(player, place, x, y)
            building.building_land = self.building_land
            if blocked_exit:
                building.block(blocked_exit)
            building.hp = self.type.hp_max - self.damage_during_construction
            building.notify("complete")

    @property
    def is_fully_repaired(self):
        return False


class Building(_Building):

    is_buildable_anywhere = False
    is_buildable_on_exits_only = False
    is_buildable_near_water_only = False
    provides_survival = True
    stat_type = "building"
    is_production = 0  # 默认不可生产
    production_type = "resource1"  # 默认生产资源类型为resource1（金子）
    production_cost = (0, 0)  # 默认不消耗资源
    production_time = 0  # 默认生产时间为0
    production_qty = 0  # 默认产量为0
    is_producing = False  # 当前是否正在生产
    production_progress = 0  # 当前生产进度
    
    @property
    def can_start_produce(self):
        """检查建筑物是否可以在菜单中显示start_produce命令"""
        return getattr(self, "is_production", 0) == 1
