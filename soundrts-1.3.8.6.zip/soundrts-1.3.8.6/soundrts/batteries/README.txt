In this directory are the deprecated/removed Python modules still used by SoundRTS at the moment.

The files are the latest versions before their deprecation.
asynchat was edited to import the local asyncore.

telnetlib seems tedious to replace until a simple solution is found.
asyncore and asynchat will be probably replaced by asyncio at some point.