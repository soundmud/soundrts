#! .venv\Scripts\python.exe
from soundrts import clientmain

clientmain.main()
