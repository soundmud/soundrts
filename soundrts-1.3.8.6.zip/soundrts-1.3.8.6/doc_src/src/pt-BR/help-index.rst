Documenta��o
============

- `Manual do jogo <manual.htm>`_
- `Guia de unidades <units.htm>`_
- `Guia de cria��o de mapas <mapmaking.htm>`_
- `Guia para a cria��o de mods <modding.htm>`_ (em progresso)
- `Tutorial para a cria��o de AIs <aimaking.htm>`_
