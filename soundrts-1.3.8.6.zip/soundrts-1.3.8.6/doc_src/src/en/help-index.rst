.. raw:: html

   <script type="text/javascript" src="langdir.js"></script> 

Documentation
=============

- `Release notes <relnotes.htm>`_
- `Game manual <manual.htm>`_
- `Units guide <units.htm>`_
- `Map making guide <mapmaking.htm>`_
- `Modding guide <modding.htm>`_
- `Making AIs Tutorial <aimaking.htm>`_
- `Standalone server guide <server.htm>`_