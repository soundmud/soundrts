This example mod restores teleportation for the mage instead of recall.

To activate this mod, in SoundRTS.ini:
mods = teleportation
or:
mods = mod1,mod2,teleportation