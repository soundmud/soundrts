This example mod adds the orcs as a faction. Multiplayer maps select the faction randomly for each player.

To activate this mod, in SoundRTS.ini:
mods = orc
or:
mods = mod1,mod2,orc