#! .venv\Scripts\python.exe
from soundrts import server

server.main()
